<!DOCTYPE html>
<html>
<title>Vihang | Conscientia 2018</title>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="../images/clogob.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/main.css" />
    <meta name="robots" content="noindex">
<script src="../js/main.js"></script>
<div id="load_screen">
    <img src="../images/clogow.png" id=conspic>
    <div id="loading"></div>
</div>
<link rel="stylesheet" media="screen" href="../css/style.css">
<head>
<style>
.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
</style>
</head>
<body onload="hideloader();">

    <div class="topnav" id="myTopnav">
        <a href="../" class="active"><img src="../images/clogow.png" id="logo" ></img></a>
        <a class="n" href="Aparimit.php">Aparimit</a>
        <a class="n" href="Bot in the act.php"  class="active">Bot In Act</a>
        <a class="n" href="Cyberia.php">Cyberia</a>
        <a class="n" href="Kaleidoscope.php">Kaleidoscope</a>
        <a class="n" href="Mechamorphosis.php">Mechamorphosis</a>
        
        <a class="n" href="Paripath.php">Paripath</a>
        <a class="n" href="Philosophiae.php">Philosophiae</a>
        <a class="n" href="Vihang.php">Vihang</a>
          <a class="n" onclick="document.getElementById('contact').style.display='block'" >LogIn</a>            <div id="contact" class="w3-modal"> 
                <div class="w3-modal-content w3-animate-zoom">
                    <div class="w3-container w3-black w3-leftbar">
                       <span onclick="document.getElementById('contact').style.display='none'" class="w3-button w3-display-topright w3-large"><p id="close">x</p></span>
                        <h1 id="Log">LogIn</h1>
                    </div>
                    <div class="w3-container w3-black w3-leftbar">
                    <br>
                    <div>
                            <!-- <h2>Login Information</h2> -->
                           
                           <br>
                            <div>
                                <label for="username" id="user">Username</label>
                                <br><br>
                                <input type="text"  class="w3-input w3-padding-5 w3-border-bottom w3-black" name="username" id="username">
                            </div>
                            <br>    
                            <div>
                                <label for="password" id="user">Password</label>
                                <br>
                                <br>
                                <input type="password" class="w3-input w3-padding-5 w3-border-bottom w3-black" name="password" id="password">
                            </div>    
                            <p id="signerr"></p>
                            <button onclick="login()" class="w3-button w3-hover-none w3-tiny w3-black" ><p id="user1">Login</p></button>
                            
                        </div>
                       <p> <a href="../pass.php" target="_blank">Forgot your password?</a> </p> 
                         <p> <a href="../signup.html" target="_blank">Sign Up</a> </p>            
                     </div>
                   </div>
            </div>
                  <a class="n" href="javascript:void(0);" style="font-size:20px;color:silver "id="icon" onclick="myFunction()">&#9776;</a>
                    </div>


                    <div class="w3-display-container w3-animate-opacity">
  <img src="img/Bristol_F2B_D8096_flying_1.jpg" alt="boat" style="width:100%;min-height:350px;max-height:400px;"><h1 class="w3-animate-bottom centered titleeve">VIHANG</h1>
  <div class="w3-container w3-display-bottomleft w3-margin-bottom">  
  </div>
</div>	
<div class="w3-row-padding w3-center w3-margin-top">
  <div class="w3-quarter">
  <div class="w3-card w3-container cpurple w3-margin-top" style="min-height:460px">
    <h3 class="Ab1">Air Strike</h3><br>	
    <img src="../images/logo/Airstrike (1).png" height="35%" width="35%"></img>
    
     <p class="Ab"><button onclick="document.getElementById('AboutAirStrike').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
    </p>
    <div id="AboutAirStrike" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('AboutAirStrike').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Air Strike</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br>
           <p class="Ab">
       “To invent an airplane is nothing. To build one is something. To fly is everything” - Otto Lilienthal 
      <br><br>In a distant parallel universe, the world is under the threat of unparalleled beings who attack from above, whose skills in air are so miraculous as if they can wield wind. The world, under those dark spirits, is short of people with skills in air. That world has sent us a grant for recruiting people who can make effective design for a remotely piloted aircraft which can exhibit its maneuverability and make a worthy impression at the air show.
	  <br><br>So, my fellow beings on earth, this is opportunity to use your designing creativity and maneuvering skills to save the world in parallel universe. Your task is to design and build a remote controlled aircraft using only electric motors agreeing with given specifications, which can complete the given task in shortest possible time and land safely in the landing zone.
      </p>
      <br><br><h3  class="Ab2">Specifications</h3>
      <ol class="list">
      <li>It should be a powered, fixed wing aircraft (Hovercrafts, helicopters, airships, etc. are not allowed).</li>
      <li>A team can participate with only one aircraft and the same aircraft has to be used for all the rounds.</li>
      <li>The aircraft should only be powered by electric motors. No other means of propulsion to be used(use of IC engines or any other method is prohibited).</li>
      <li>The voltage between any two points in the circuit should not be more than 15V.</li>
      <li>Maximum weight of the whole aircraft cannot exceed 1.2kg at any point of time during the competition.</li>
	  <li>Length of the aircraft should not be more than 1m and wing span should not exceed 1m.  .</li>
	  <li>The aircraft should be hand launched. (any other launching mechanism is not allowed)</li>
	  <li>Use of gyroscopes is prohibited.	</li>
	  <li>Aircraft must be capable to demonstrate pitch and roll. </li>
	  <li>All the participants are expected to build the aircraft themselves. Aircraft built using Ready-to-fly kits or Almost ready to fly kits will be disqualified.</li>
	  <li>Participants are free to use any material to build the aircraft.</li>
	  <li>The team has to bring their own transmitter-receiver kits for the competition (the organizers are not going to provide any transmitter).</li>
	  <li>An aircraft which is not adhering with any of the above specification will be disqualified.</li>
      </ol> 
      <br><br><h3  class="Ab2">Format</h3>
      <ol class="list">
	 <p class="Ab"> Round 1</p>
	  <ol>
      <li>The dimensions, weight, power, etc. of the aircraft will be verified to check whether they are compatible with the given specifications.</li>
      <li>Flying abilities of the team has to be demonstrated with pitch and roll maneuvers of the aircraft.</li>
      <li>Pilot should be able to make atleast two loop with nearly constant elevation and land safely back to ground.</li>
      <li>Round 1 is just for qualifying purpose so no scoring will be done. </li>
	  </ol>
     <p class="Ab">Round 2</p>
	  <ol>
      <li>In the 2nd round the teams have to show their stunts with the aircrafts according to our problem statement.</li>
      <li>Task 1 – The aircraft have to drop the payload at the payload dropping zone.</li>
      <li>Task 2 – The Aircraft need to pass through a post which is 8ft above ground and 24ft wide, twice within 45 sec. Time starts after passing through the post for the first time. </li>
      <li>Task 3 – Pilot should be able to perform any no. of or all the following maneuvers:
		<ul style="padding-left: 20px;">
		<li>Stall Turn</li>
		<li>Inside Loop </li>
		<li>Outside Loop</li>
		<li>The 360 degrees Roll</li>
		<li>Immelmann Turn</li>
		<li>Split S (Reverse Immelmann Turn)</li>
		</ul>
	  </li>
	  <li>Task 4 –The aircraft has to land smoothly and successfully in the landing zone within specified limits of the runway.</li>
	  </ol>
	  </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 30,000</p>
<!--       <br><br><h3  class="Ab2">Prize Money</h3>
	  <ol class="list">
    <li>First Prize: ₹</li>
    <li>Second Prize: ₹ </li>
    </ol>
 -->      </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesAirStrike').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
    </p><div id="RulesAirStrike" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('RulesAirStrike').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">AirStrike</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3  class="Ab2">Rules</h3>
           <ol class="list">
      <p class="Ab"> A team can consist of maximum 5 members. The members can be students of different institutes.</p>
			   <br>
			   <p class="Ab"> Round 1</p>
	  <ol>
	  <li>The aircraft has to be hand-launched from the launch zone of the arena (shown in the figure). </li>
	  <li>The person launching the aircraft has to be present within the launch zone at the time when the aircraft leaves his/her hand.</li>
	  <li>The team has to fly within the specified boundaries shown in the figure. Violation will lead to disqualification of the team.</li>
	  <li>Each team will have 3 trials to complete the task.</li>
	  <li>The maximum time for each team will be 5 minutes within which they have to complete the task including all necessary repairs between each trial (if required). Time for each team starts with the launch for the 1st trial.</li>
	  </ol>
			   <br>
			   <p class="Ab"> Round 2</p>
	  <ol>
	  <li>Each team will have 2 trials. The better of the two will be considered for judgment. N.B: Use of the 2nd trial is optional if 1st trial is successful.</li>
	  <li>The aircraft has to be hand-launched from the launch zone of the arena (shown in the figure). </li>
	  <li>The person launching the aircraft has to be present within the launch zone at the time the aircraft leaves his/her hand.</li>
	  <li>Final payload position should be inside the loop.</li>
	  <li>Landing should take place within the landing zone. Landing will be considered successful only if the touchdown point is after the starting line of the landing zone and whole of the aircraft body is within limits of the landing zone after stopping. </li>
	  <li>If the aircraft stops after successful landing within the different zones of the landing zone, points will be awarded accordingly (as shown in figure)(Total zones = 3). </li>
	  <li>Bonus points will be awarded for soft-landing. A landing is termed as soft-landing if the propeller is undamaged and all parts of the aircraft remain attached to it after the aircraft comes to halt.</li>
	  <li>Maximum time for successful completion of the task is 15 min. This time limit includes the time for both the chances, repairs and any other maintenance work (if required). </li>
	  <li>Team should complete the task in minimum possible time to earn more points.</li>
	  <li>Time of flight starts as soon as the aircraft is in air and stops when the aircraft finally comes to halt.</li>
	  <li>No partial marks will be awarded for half-done task.</li>
	  </ol>
	  </ol> 
      
	  
            <br><br><h3  class="Ab2">Judging Criteria</h3>
           <ol class="list">
		   <li>Payload : 125 points</li>
		   <li>Landing : 100*zone number + 75(soft landing) points</li>
		   <li>Maneuvers : 60* number of maneuvers points</li>
		   <li>Post passing (Refer Task 3) : 100 points</li>
		   <li>Time of flight : (-1) *Time of flight * 0.5 points</li>
		   </ol>
      
  </div>
  </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactAirStrike').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
    </p><div id="ContactAirStrike" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('ContactAirStrike').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Air Strike</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3  class="Ab2">Contacts</h3>
           <ol class="list">
      <li>Kunal Garg : 9447785203</li>
      <li>Tarun N. Chavan : 9447784119 </li>
      </ol>
      </div>
      </div>
  </div>
    <button onclick="event_reg('rc_plane')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
    </div>
  </div>
  
  <!--   event one ends here -->
  <!--   event1 sarts here copy and paste this code and change the content accordingly -->
  <div class="w3-quarter">
  <div class="w3-card w3-container cpurple w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Blast Off</h3><br>	
  <img src="../images/logo/water rocket.png" height="35%" width="35%"></img>
  
  <p class="Ab"><button onclick="document.getElementById('AboutBlastOff').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutBlastOff" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
  <div class="w3-container w3-black w3-display-container">
    <span onclick="document.getElementById('AboutBlastOff').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
    <h1 style="font-family:'icon1'; font-size:38px;">Blast Off</h1>
  </div>
  <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
      <br>
     <p class="Ab">
  ROCKETS!!! The stuff of our dreams when we were kids. But did you know that the pressure of  water in a bottle can model a rocket ?
So, this Conscientia,  get your gear,  bring out the engineer in you and brace yourselves to "BLAST OFF" !!

  </p>
  <br><br><h3  class="Ab2">Format</h3>
  <ol class="list">
  <li>There will be two rounds. </li>
  <li>First round will be purely based on range of the rocket</li>
  <li>Second round will be judged taking into account the range, time and deviation from straight flying path.</li>
  <li>Each team can have only 2 rockets which should be presented before start of the competition.</li>
  
  </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 10,000</p>
  </div>
  </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesBlastOff').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesBlastOff" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
  <div class="w3-container w3-black w3-display-container">
    <span onclick="document.getElementById('RulesBlastOff').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
    <h1 style="font-family:'icon1'; font-size:38px;">Blast Off</h1>
  </div>
  <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
      
<br><br><h3  class="Ab2">Rules</h3>
     <ol class="list">
  <li>	A team can consist of any number of members. Students from different colleges can form a team. </li>
  <li>	This event is open to all college students with valid ID cards. </li>
  <li>	Maximum 2 rockets and 1 launcher per team are allowed.  Both the rockets can be used in round 1 and round 2.</li>
  <li>	Only single stage rockets are allowed.</li>
  <li>	Boosters and Multistage rockets are not allowed. </li>
  <li>	All the required components (along with launcher) have to be brought by the participants. No two teams can share a single launcher.</li>
  <li>	Model can be of any size or shape.</li>
  <li>	Maximum pressure allowed is 60psi. </li>
  <li>	You can choose any initial angle according to your design. </li>
  <li>	Only water and Foot pump will be provided.</li>
  <li>	Electronically controlled models and Parachutes are not allowed. </li>
  <li>	In case of tie between two or more teams, score of first round and some other factors like time of flight will be taken into account.</li>
  <li>	Organizer’s decision will be final and binding. 	</li>
  <li>	The organizers may change any of the above rules at any time. </li>
  </ol>
<br><br><h3  class="Ab2">Judging Criteria</h3>
     <ol class="list">
  <li>	First round will be on range basis. Top 5 teams with maximum range will qualify for second round. Every team will get two chances in first round.</li>
  <li>	In second round, again two launches will be given. Here, range of the rocket, deviation of the rocket and time of flight will be judging factors.</li>
  <li>	Scoring of second round will be: S=R-2D+2T. Here, S is total score, R is the range in me-ters, D is deviation in meters and T is time of flight in seconds.</li>
  <li>	Top two teams will be declared winners as 1st and 2nd position.</li>	
  </ol>  
  </div>
  </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactBlastOff').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactBlastOff" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
  <div class="w3-container w3-black w3-display-container">
    <span onclick="document.getElementById('ContactBlastOff').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
    <h1 style="font-family:'icon1'; font-size:38px;">Blast Off</h1>
  </div>
  <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
      <br><br><h3  class="Ab2">Contact</h3>
     <ol class="list">
  <li>Saathvika  : 9447784877</li>
  <li>Sai teja  : 9447785361</li>
  </ol>
  </div>
  </div>
  </div>
  <button onclick="event_reg('water_rocket')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
  </div>
  
  <!--   event one ends here -->
  <!--   event1 sarts here copy and paste this code and change the content accordingly -->
  <div class="w3-quarter">
  <div class="w3-card w3-container cpurple w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Techglide</h3><br>	
  <img src="../images/logo/airglide.png" height="35%" width="35%"></img>
  
  <p class="Ab"><button onclick="document.getElementById('AboutTechglide').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutTechglide" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
  <div class="w3-container w3-black w3-display-container">
    <span onclick="document.getElementById('AboutTechglide').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
    <h1 style="font-family:'icon1'; font-size:38px;">Techglide</h1>
  </div>
  <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
      <br>
     <p class="Ab">
  “Still glides the stream, and shall forever glide; The form remains, the function never dies.”  -  William Wordsworth
  <br><br>Come and participate in this competition and show your skills to design a glider that stays in air for the maximum time while covering a good amount of distance.
  </p>
  <br><br><h3  class="Ab2">Specifications</h3>
  <ol class="list">
  <li>Dimension of glider should not exceed 60 cm along the body and maximum wingspan of 80 cm can be used. </li>
  <li>You can use any material for making the glider, e.g. paper, coroplast, forex, or Balsa wood. </li>
  <li>Ready to Fly kits are not allowed and teams using such kit can be disqualified at any stage of the competition. </li>
  <li>Gliders will be hand launched and no other mechanism for launching can be used. </li>
  <li>Glider should be unpowered, use of propeller, however small is strictly prohibited.</li>
  <li>No electronics can be used in glider, for e.g. using gyroscope for stability etc. </li>
  <li>Any malpractice will lead to immediate disqualification. </li>
  </ol> 
                 <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 7,500</p>

<!--   <br><br><h3  class="Ab2">Prize Money</h3>
  <ol class="list">
    <li>First Prize: ₹</li>
    <li>Second Prize: ₹ </li>
    </ol>
 -->  </div>
  </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesTechglide').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesTechglide" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
  <div class="w3-container w3-black w3-display-container">
    <span onclick="document.getElementById('RulesTechglide').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
    <h1 style="font-family:'icon1'; font-size:38px;">Techglide</h1>
  </div>
  <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
      <br><br><h3  class="Ab2">Rules</h3>
     <ol class="list">
  <li>Each team should comprise of maximum 4 members. </li>
  <li>There will be a single round and each team will be given two chances and better of the two scores will be considered for the judgement. </li>
  <li>Scores will be based on Range, Deviation from the straight path (Accuracy) and time of flight (to give weightage to gliding).  </li>
  <li>In case of tie between two or more teams, appropriate decision will be taken by the organizers. </li>
  <li>Organizer’s decision will be final and binding. </li>
  <li>The organizers may change any or all of the above rules at any time. </li>
  <li>Teams with gliders not adhering to the specification below will be disqualified. </li>
  </ol>
<br><br><h3  class="Ab2">Judging Criteria</h3>
     <ol class="list">
  <li>Total Score, T = R -0.5*d+3*t, where R is the Range, d is the deviation and t is the time of flight.
</li>
  <li>Top two teams will be declared as 1st and 2nd winner according to their final points. </li>
  </ol>   
  </div>
  </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactTechglide').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactTechglide" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
  <div class="w3-container w3-black w3-display-container">
    <span onclick="document.getElementById('ContactTechglide').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
    <h1 style="font-family:'icon1'; font-size:38px;">Techglide</h1>
  </div>
  <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
      <br><br><h3  class="Ab2">Contacts</h3>
     <ol class="list">
  <li>Manas - 9568809222</li>
  <li>Mohit - 9447784711  </li>
  </ol>
  </div>
  </div>
  </div>
  <button onclick="event_reg('glider_making')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
  </div>
  
  <!--   event one ends here -->
  <!--   event1 sarts here copy and paste this code and change the content accordingly -->
  
  
  <!--   event one ends here -->
  <!--   event1 sarts here copy and paste this code and change the content accordingly -->
  <div class="w3-quarter">
  <div class="w3-card w3-container cpurple w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Drone Zone</h3><br>	
  <img src="../images/logo/Drone.png" height="35%" width="35%"></img>
  
  <p class="Ab"><button onclick="document.getElementById('AboutDroneContest').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutDroneContest" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
  <div class="w3-container w3-black w3-display-container">
    <span onclick="document.getElementById('AboutDroneContest').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
    <h1 style="font-family:'icon1'; font-size:38px;">Drone Zone</h1>
  </div>
  <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
      <br>
     <p class="Ab">
  The hobby industry is exploding with model aircraft, and multi-rotors are no exception. These fascinating aircrafts combine the flight characteristics of both a plane and a helicopter. Students will be judged in three aspects of a multirotor that is on the expertise of their Design, Manufacturing and flying skill.
  </p>
  <br><br><h3  class="Ab2">Model Specifications</h3>
  <ol class="list">
  <li>The model must fit within a circle of diameter 50 cm. Minimum dimension of the rotor
should be 25cm (diagonally). </li>
  <li>Metal Propellers are not allowed.</li>
  <li>Any material can be used for construction.</li>
  <li>Arduino and other boards can be directly used. Team may or may not use pre-programmed boards. </li>
  <li>Exchanging of models is strictly not allowed. Each team must have its own model. </li>
  <li>Throughout the event, in all the rounds only one model must be used. </li>
  <li>RTF (Ready to Fly) models will not be allowed.</li>
  <li>Already built frames can be used.</li>
  </ol> 
  <br><br><h3  class="Ab2">Format</h3>
  <ol class="list">
  <li>There will be only one round in the competition</li>
  <li>Two attempts will be given to each team and best of two will be counted.</li>
  <li>In the end, the team having the highest total points will be the winner.</li>
  </ol> 
  <br><br><h3  class="Ab2">Problem Statement</h3>
  <ol class="list">
  <li>Maximum 150 points for this round. 10 point will be given when the center of model will be in inner circle at each point of landing.</li>
  <li>5 points will be given when the center of model is outside the small circle and inside the outer circle. </li>
  <li>No points will be given if the center of model is outside the bigger circle. Also, it will lead to the end of team’s attempt of the round. </li>
  <li>30 points will be given if model completely landed on final ending position. In this case the legs of model should be on lines of that position that describe in arena for quadcopter, hexacopter and octacopter. No points will be given if model does not lie on the lines perfectly.  </li>
  <li>Model has to go through 1st, 2nd, 3rd up to 5th circle without skipping any circle. </li>
  <li>If team miss any of the circle, no points will be given for that circle. Point will not be given until the model is not completely landed. </li>
  <li>Maximum time after take-off from starting point will be 7 min.  </li>
  <li>There will be no time-out after take-off from starting point and before team finish. </li>
  </ol> 
  <br><br><h3  class="Ab2">Materials and services provided</h3>
  <ol class="list">
  <li>Electric Sockets (220-230V) will be provided for charging the batteries.</li>
  <li>Students are strongly suggested to bring all the materials they require to repair their model. We won’t provide any of the materials.</li>
  </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 30,000</p>
<!--   <br><br><h3  class="Ab2">Prize Money</h3>
  <ol class="list">
    <li>First Prize: ₹</li>
    <li>Second Prize: ₹ </li>
    </ol>
 -->  </div>
  </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesDroneContest').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesDroneContest" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
  <div class="w3-container w3-black w3-display-container">
    <span onclick="document.getElementById('RulesDroneContest').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
    <h1 style="font-family:'icon1'; font-size:38px;">Drone Zone</h1>
  </div>
  <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
      <br><br><h3  class="Ab2">Rules</h3>
     <ol class="list">
  <li>Any student of any academic institution is eligible to participate. </li>
  <li>A team can consist of maximum 5 members. Students from different colleges can form a team.  </li>
  <li>There will be no trial round.  </li>
  <li>Team should not lift the bot to improve their position.</li>
  <li>Any failed attempt of landing (touch to the ground), which do not get team any point and will lead to the end of the round. </li>
  <li>The organizers reserve all rights to change any or all of the above rules. </li>
  </ol> 
  </div>
  </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactDroneContest').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactDroneContest" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
  <div class="w3-container w3-black w3-display-container">
    <span onclick="document.getElementById('ContactDroneContest').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
    <h1 style="font-family:'icon1'; font-size:38px;">Drone Zone</h1>
  </div>
  <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
      <br><br><h3  class="Ab2">Contacts</h3>
     <ol class="list">
  <li>Anuj Malik : 9497300445</li>
  <li>Chinmay : 9497300121 </li>
  </ol>
  </div>
  </div>
  </div>
  <button onclick="event_reg('drone_racing')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
  </div>
  


</div>
</body>