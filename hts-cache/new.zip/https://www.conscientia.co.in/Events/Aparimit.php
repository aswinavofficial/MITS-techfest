<!DOCTYPE html>
<html>
<title>Aparimit | Conscientia 2018</title>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="../images/clogob.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/main.css" />
<script src="../js/main.js"></script>
    <meta name="robots" content="noindex">
<div id="load_screen">
    <img src="../images/clogow.png" id=conspic>
    <div id="loading"></div>
</div>
<link rel="stylesheet" media="screen" href="../css/style.css">
 
<head>
<style>
.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
</style>
</head>
<body onload="hideloader();">
  

  <div class="topnav" id="myTopnav">
      <a href="../" class="active"><img src="../images/clogow.png" id="logo" ></img></a>
      <a class="n" href="Aparimit.php">Aparimit</a>
      <a class="n" href="Bot in the act.php"  class="active">Bot In Act</a>
      <a class="n" href="Cyberia.php">Cyberia</a>
      <a class="n" href="Kaleidoscope.php">Kaleidoscope</a>
      <a class="n" href="Mechamorphosis.php">Mechamorphosis</a>      
      <a class="n" href="Paripath.php">Paripath</a>
      <a class="n" href="Philosophiae.php">Philosophiae</a>
      <a class="n" href="Vihang.php">Vihang</a>
          <a class="n" onclick="document.getElementById('contact').style.display='block'" >LogIn</a>        <div id="contact" class="w3-modal"> 
            <div class="w3-modal-content w3-animate-zoom">
                <div class="w3-container w3-black w3-leftbar">
                   <span onclick="document.getElementById('contact').style.display='none'" class="w3-button w3-display-topright w3-large"><p id="close">x</p></span>
                    <h1 id="Log">LogIn</h1>
                </div>
                <div class="w3-container w3-black w3-leftbar">
                <br>
                <div>
                        <!-- <h2>Login Information</h2> -->
                       
                       <br>
                        <div>
                            <label for="username" id="user">Username</label>
                            <br><br>
                            <input type="text"  class="w3-input w3-padding-5 w3-border-bottom w3-black" name="username" id="username">
                        </div>
                        <br>    
                        <div>
                            <label for="password" id="user">Password</label>
                            <br>
                            <br>
                            <input type="password" class="w3-input w3-padding-5 w3-border-bottom w3-black" name="password" id="password">
                        </div>    
                        <p id="signerr"></p>
                        <button onclick="login()" class="w3-button w3-hover-none w3-tiny w3-black" ><p id="user1">Login</p></button>
                        
                    </div>
                   <p> <a href="../pass.php" target="_blank">Forgot your password?</a> </p> 
                     <p> <a href="../signup.html" target="_blank">Sign Up</a> </p>            
                 </div>
               </div>
              </div> <a class="n" href="javascript:void(0);" style="font-size:20px;color:silver "id="icon" onclick="myFunction()">&#9776;</a>
                </div>



                <div class="w3-display-container w3-animate-opacity">
  <img src="img/aparimit.jpg" alt="boat" style="width:100%;min-height:350px;max-height:400px;"><h1 class="w3-animate-bottom centered titleeve1">APARIMIT</h1>
  <div class="w3-container w3-display-bottomleft w3-margin-bottom">  
  </div>
</div>	
<div class="w3-row-padding w3-center w3-margin-top">

 <!--   event1 sarts here copy and paste this code and change the content accordingly -->
 <div class="w3-quarter">
  <div class="w3-card w3-container cblue w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Cosmic Clash</h3><br>	
  <img src="../images/logo/cosmic clash icon.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutCosmicClash').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutCosmicClash" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutCosmicClash').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Cosmic Clash</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large">
          <br>
         <p class="Ab">
          "It is indeed a feeble light that reaches us from the starry sky. But what would human thought have achieved if we could not see the stars?" - Jean Perrin

          
    <br><br>Do you think you have what it takes to battle it out to be the ultimate astro-geek? Then cosmic clash is the place for you. Come, test your knowledge in astronomy and astrophysics and become the conqueror of the cosmos.
    </p>
    <h3  class="Ab2">Format</h3>
    <ol class="list">
    <li>The event will consist of two rounds.</li>
    <li>Prelims will be a written quiz comprising of questions from basic Astronomy and Astrophysics.</li>
    <li>The format of the finals will be disclosed on the spot</li>
    </ol> 
     <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹4,500</p>

<!--     <ol class="list">
        <li>First Prize: ₹</li>
        <li>Second Prize: ₹ </li>
        </ol> 
 -->  </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesCosmicClash').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesCosmicClash" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesCosmicClash').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Cosmic Clash</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>  Any student with a valid college ID card can participate.</li>
    <li> Each team may consist of at most two members.</li>
    <li>Inter-college teams are also allowed. </li>
    <li>The decision of event organizers will be final and binding.</li>
     </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactCosmicClash').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactCosmicClash" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactCosmicClash').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Cosmic Clash</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Milan Tudu : 9447785144</li>
    <li>Ajay Potdar : 9497300447 </li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('cosmic_clash')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-quarter">
  <div class="w3-card w3-container cblue w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Astroreflection</h3><br>	
  <img src="../images/logo/astroreflections icon.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutAstroreflection').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutAstroreflection" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutAstroreflection').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Astroreflection</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
          “Who are we? We find that we live on an insignificant planet of a humdrum star lost in a galaxy tucked away in some forgotten
          corner of a universe in which there are far more galaxies than people.” – Carl Sagan
    <br><br>We now know that these asterisks are
    huge spheres of burning hydrogen. But what happens when the Hydrogen runs out, if it ever does? Are all the white speckles
    we see in the sky stars? If not, what exactly are they?<br> <br>We expect you to answer some of these questions and some questions
    of your own. The only condition is to make a poster to display that information. So, pick up your pen and/or your phone and
    start thinking of a topic, (two topics are just as fine) and create an attractive technical poster out of your idea. 
    </p>
    <br><br><h3  class="Ab2">Format</h3>
    <ol class="list">
    <li>The event consists of 2 rounds.</li>
    <li>All the participating teams have to submit an abstract describing the poster. It must be simple and informative. The appropriate references must also be mentioned.</li>
    <li>Based on the abstract few teams will be selected to the final round and they will be notified. </li>
    <li>Posters will be displayed during the main event and the teams will have to present their poster before the judges.</li>
    <li>Teams will be judged based on their poster presentation, information about the topic, posters content and their explanatory skills.</li>
    <li>The charges incurred to print the posters have to be arranged by the participants themselves.</li>
    </ol> 
         <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 5,500</p>

<!--     <br><br><h3  class="Ab2">Prize Money </h3>
    <ol class="list">
        <li>First Prize: ₹</li>
        <li>Second Prize: ₹ </li>
        </ol> 
 -->    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesAstroreflection').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesAstroreflection" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesAstroreflection').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Astroreflection</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>This event is open to all college students with valid ID cards.</li>
    <li>A team may consist of a maximum of 2 members.</li>
    <li>The poster topics must be related to astronomy or cosmology. </li>
    <li>A team can submit a maximum of two posters.</li>
    <li>Poster should be in .png or .jpeg format.</li>
    <li>Posters can be made on an A1 sheet or alternatively you can use either two A2 sheets. </li>
    <li>Text size must be chosen such that it is readable from a comfortable distance.</li>
    <li>The decision of the event organizers will be final and binding under all circumstances.</li>
    </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactAstroreflection').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactAstroreflection" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactAstroreflection').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Astroreflection</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Ajay Potdar : 9497300447</li>
    <li>Jesal Kotak: 9447788057 </li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('astroreflection')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-quarter">
  <div class="w3-card w3-container cblue w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Night Sky Hunt</h3><br>	
  <img src="../images/logo/sky hunt icon.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutNightSkyHunt').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutNightSkyHunt" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutNightSkyHunt').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Night Sky Hunt</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
            "Though my soul may set in darkness, it will rise in perfect light; I have loved the stars
            too fondly to be fearful of the night." - Sarah Williams 
    <br><br> The night sky has been a host for many mysterious objects. Thanks
    to pioneers like Galileo and his modified telescope, the quest for these mysterious objects has been made easier and since
    then the hunt is unending. Be a part of this hunt and grab your opportunity to find your way through the night sky.
    </p>

         <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 6,000</p>

<!--     <br><br><h3  class="Ab2">Prize Money </h3>
    <ol class="list">
        <li>First Prize: ₹</li>
        <li>Second Prize: ₹ </li>
        </ol> 
 -->    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesNightSkyHunt').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesNightSkyHunt" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesNightSkyHunt').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Night Sky Hunt</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>Maximum two members are allowed in a team.</li>
    <li>A maximum of 2 participants in a team can register.</li>
    <li>The event will consist of two rounds: prelims and finals. </li>
    <li>Prelims will be a written round to test the knowledge of participants in observational astronomy and telescopes.</li>
    <li>Finals will test the ability to identify astronomical objects by using telescopes or naked eye.</li>
    <li>The participants will be given 90 minutes and objects to be identified may include Messier objects, planets, stars, sky patterns etc.</li>
    <li>The names of objects may be given directly or the participants will have to find it from the hints provided.</li>
    <li>Telescopes, Star charts and all the required materials will be provided by the organizing team.</li>
    <li>Rough handling of telescopes or damages to its components may lead to disqualification and fine.</li>
    <li>Cheating will not be tolerated. Hence use of mobile phones, laptops, own star charts, books and so on are condemned.</li>
    <li>Decision of the organizers will be final.</li>
    <li>There will initially be a written elimination round, with the selected teams getting to participate in the finals.</li>
    <li>Within the given time the participants have to identify maximum of the given objects.</li>
    <li>The accuracy of identification of objects and the knowledge about them will be also considered as evaluation criteria.</li>
  </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactNightSkyHunt').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactNightSkyHunt" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactNightSkyHunt').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Night Sky Hunt</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Ajay Potdar : 9497300447</li>
    <li> Kiran Jayasurya : 8553504008 </li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('night_sky_hunt')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-quarter">
  <div class="w3-card w3-container cblue w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Astro ABC</h3><br>	
  <img src="../images/logo/Astro ABC.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutAstroABC').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutAstroABC" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutAstroABC').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Astro ABC</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
            "For my part I know nothing with any certainty, but the sight of stars always makes me dream." - Vincent Van Gogh.
    <br><br>Since ancient
    times we have always wondered what was really up in the skies and devised many methods to find out what it really was.<br> Having
    said that, allow us to take you on an activity based ride to display the beauty of the universe to you.
    </p>
     <br><br><h3  class="Ab2">Format</h3>
    <ol class="list">
    <li>Prelims will be a written round with questions from basic physics and mathematics relevant to astronomy. </li>
    <li> Teams selected from the prelims will be notified and will get to participate in the finals.</li>
    <li>Finals will be five 'Activity based rounds'. </li>
    <li> Further details will be disclosed during the event.</li>
    </ol> 
         <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 5,000</p>
<!--     <br><br><h3  class="Ab2">Prize Money </h3>
    <ol class="list">
        <li>First Prize: ₹</li>
        <li>Second Prize: ₹ </li>
        </ol> 
 -->    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesAstroABC').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesAstroABC" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesAstroABC').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Astro ABC</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>Any student with a valid college ID card can participate.</li>
    <li>Each team may consist of at most two members. Intercollege teams will be allowed.</li>
    <li>The decision of event organizers will be final and binding. </li>
   </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactAstroABC').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactAstroABC" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">

        <span onclick="document.getElementById('ContactAstroABC').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Astro ABC</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li> Ajay Potdar:9497300447</li>
    <li> Kiran Jayasurya: 8553504008 </li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('astro_abc')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
</div>

<!--   event one ends here -->































</div>
</body>