<!DOCTYPE html>
<html>
<head>
</head>
<style>
    @font-face{
        font-family: 'icon1';
        src: url('font/earthorbiter.ttf');
    }

    @font-face{
        font-family: 'icon2';
        src: url('font/RawengulkSans.ttf');
    }


    input:focus{
        outline: none;
    }
    body{
        width: 100vw;
        height: 100vh;
        overflow: hidden;
        background: black;
        text-align: center;
        padding: 0;
    }

    #form1
    {
        font-size: 3.5vh;
        width:55vh;
        border: 3px solid azure;
        border-radius: 2px;
        margin: 30vh auto 0;
        padding: 2.5%;

    }

    #form1 label{
        font-family: 'icon1';
        color: azure;
        margin-bottom:30px;
        font-size: 3vh;
    }

    #form1 input
    {
        width:50%;
        margin-left: 20px;
        background-color: black;
        border: none;
        border-bottom: 2px solid azure;
        color: white;
        font-family: 'icon2';
        padding:20px;
        margin-bottom: 20px;
        font-size: 2.5vh;
    }

    #form1 p {
        font-family: 'icon1';
        color:skyblue;
        margin-bottom:2vh;
    }

    #form1 #button
    {
        margin-top: 10px;
        border: 2px solid azure;
        font-family: 'icon1';
        font-size: 2vh;
        cursor: pointer;
    }

    #form1 #button:hover
    {
        border:3px solid skyblue;
        color: skyblue;
    }

    #form2
    {
        font-size: 2.5vh;
        width: 75%;
        border: 3px solid azure;
        border-radius: 2px;
        margin: 15vh auto 0;
        padding: 2.5%;
    }

    #form2 label{
        font-family: 'icon1';
        color:skyblue;
    }

    #form2 input
    {
        display: block;
        background-color: black;
        border: none;
        font-size: 2.5vh;
        border-bottom: 2px solid azure;
        color: white;
        font-family: 'icon2';
        padding:10px;
        margin:0px auto 10px;
        width: 80%;
    }

    #form2 #submit
    {
        display: inline-block;
        padding: 20px;
        width: auto;
        border:3px solid transparent;
        font-family: 'icon1';
        font-size: 2vh;
    }

    #form2 #submit:hover
    {
        border:3px solid skyblue;
        color: skyblue;
        cursor: pointer;
    }
    h5{
        color: azure;
        font-size: 30px;
    }
</style>
<body>

	<form method="POST" action="pass.php" id="form1" >
        <p>Forgot password</p>  
        <label for = "email"> Email ID:</label><br>
        <input type="email" name="email" required><br>
        <input id="button" type="submit" name="Send_Link" value="Send Link">
    </form>
	</body>
</html>
