<!DOCTYPE html>
<html>
<title>Paripath | Conscientia 2018</title>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="../images/clogob.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/main.css" />
<script src="../js/main.js"></script>
    <meta name="robots" content="noindex">
<link rel="stylesheet" media="screen" href="../css/style.css">
<div id="load_screen">
    <img src="../images/clogow.png" id=conspic>
    <div id="loading"></div>
</div>
<head>
<style>
.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
</style>
</head>
<body onload="hideloader()">

    <div class="topnav" id="myTopnav">
        <a href="../" class="active"><img src="../images/clogow.png" id="logo" ></img></a>
        <a class="n" href="Aparimit.php">Aparimit</a>
        <a class="n" href="Bot in the act.php"  class="active">Bot In Act</a>
        <a class="n" href="Cyberia.php">Cyberia</a>
        <a class="n" href="Kaleidoscope.php">Kaleidoscope</a>
        <a class="n" href="Mechamorphosis.php">Mechamorphosis</a>
        
        <a class="n" href="Paripath.php">Paripath</a>
        <a class="n" href="Philosophiae.php">Philosophiae</a>
        <a class="n" href="Vihang.php">Vihang</a>
          <a class="n" onclick="document.getElementById('contact').style.display='block'" >LogIn</a>        <div id="contact" class="w3-modal"> 
            <div class="w3-modal-content w3-animate-zoom">
                <div class="w3-container w3-black w3-leftbar">
                   <span onclick="document.getElementById('contact').style.display='none'" class="w3-button w3-display-topright w3-large"><p id="close">x</p></span>
                    <h1 id="Log">LogIn</h1>
                </div>
                <div class="w3-container w3-black w3-leftbar">
                <br>
                <div>
                        <!-- <h2>Login Information</h2> -->
                       
                       <br>
                        <div>
                            <label for="username" id="user">Username</label>
                            <br><br>
                            <input type="text"  class="w3-input w3-padding-5 w3-border-bottom w3-black" name="username" id="username">
                        </div>
                        <br>    
                        <div>
                            <label for="password" id="user">Password</label>
                            <br>
                            <br>
                            <input type="password" class="w3-input w3-padding-5 w3-border-bottom w3-black" name="password" id="password">
                        </div>    
                        <p id="signerr"></p>
                        <button onclick="login()" class="w3-button w3-hover-none w3-tiny w3-black" ><p id="user1">Login</p></button>
                        
                    </div>
                   <p> <a href="../pass.php" target="_blank">Forgot your password?</a> </p> 
                     <p> <a href="../signup.html" target="_blank">Sign Up</a> </p>            
                 </div>
               </div>
              </div> <a class="n" href="javascript:void(0);" style="font-size:20px;color:silver " id="icon" onclick="myFunction()">&#9776;</a>
                </div>

                <div class="w3-display-container w3-animate-opacity">

  <img src="img/paripath.jpg" alt="boat" style="width:100%;min-height:350px;max-height:400px;"><h1 class="w3-animate-bottom centered titleeve">PARIPATH</h1>
  <div class="w3-container w3-display-bottomleft w3-margin-bottom">  
  </div>
</div>	
<div class="w3-row-padding w3-center w3-margin-top">

 <!--   event1 sarts here copy and paste this code and change the content accordingly -->
 <div class="w3-quarter">
  <div class="w3-card w3-container w3-indigo w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">LCD</h3><br>	
  <img src="../images/logo/Screwed.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutLCD').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutLCD" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutLCD').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Logical Circuit Design </h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
All set to REGISTER in the hall of fame?
Transmit the electric SPARK in you into the world of Zeros and Ones.
The CLOCK is ticking!
SWITCH on the designer in you and INVERT the reign of existing with your LOGIC.
No matter how HIGH you go, we will always GROUND you.

    </p>
    <br><br><h3  class="Ab2">Format</h3>
    <ol class="list">
    <li>The event will be conducted in two rounds: Prelims and Finals. Prelims will test your knowledge in Analog and Digital circuits.</li>
    <li>Prelims will be a written round. </li>
    <li>In the finals, selected teams will be asked to design a circuit for a defined purpose using given components. Also you could be asked to debug a given circuit for a specified output.</li>
    <li>Further details will be disclosed during the event. </li>
    </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 7,500</p>
<!--     <br><br><h3  class="Ab2">Prize Money</h3>
	<ol class="list">
    <li>First Prize: ₹</li>
    <li>Second Prize: ₹ </li>
    </ol> 
 -->    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesLCD').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesLCD" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesLCD').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Logical Circuit Design </h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>Each team can consist of maximum two members. Uses of Internet, books, calculators and any electronic devices are not permitted. </li>
    <li>All questions in both the rounds need not carry equal weightage.</li>
    <li>No circuit equipment shall be carried by the participating teams.  </li>
    <li>The circuit schematic should be approved by the organizers before the issuing of components.</li>
    <li>The decision of organizers will be final. </li>
    <li>Any kind of malpractices will lead to direct disqualification. </li>
    <li>Participants should have valid ID proof to participate in the event.</li>
    </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactLCD').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactLCD" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactLCD').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Logical Circuit Design </h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Harshitha Grandhi : 9447785758</li>
    <li>Siri Gadipudi : 9447785716 </li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('lcd')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" style="color: black">Register</button>
  </div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-quarter">
  <div class="w3-card w3-container w3-indigo w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Circuiter</h3><br>	
  <img src="../images/logo/circuiter.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutCircuiter').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutCircuiter" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutCircuiter').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Circuiter</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
Welcome to the World of Electronics. Come out of your transients and leap into steady state. Let’s make electronics fun and creative. Unleash the engineer within you to design a circuit. 
    </p>
    <br><br><h3  class="Ab2">Format</h3>
    <ol class="list">
    <li>The event comprises of 2 rounds. </li>
    <li>Preliminary round: It will be a written round based on the fundamentals of Electrical, Electronics and application based Integrated circuits. </li>
    <li>Finale: A round where you need to design a circuit based on some application. Use your logic to design and solder it on a PCB (Printed Circuit Board) within specified time. </li>
	</ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 7,500</p>
<!--     <br><br><h3  class="Ab2">Prize Money</h3>
	<ol class="list">
    <li>First Prize: ₹</li>
    <li>Second Prize: ₹ </li>
    </ol>
 -->    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesCircuiter').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesCircuiter" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesCircuiter').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Circuiter</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>The required implementation in the problem statement has to be done on a PCB (No bread boards shall be entertained). </li>
    <li>No ready-made kits will be allowed to be used. Howsoever for microcontrollers you can use the development board. Only Arduino Uno microcontroller will be provided to the participant for usage. </li>
    <li>Circuits should be soldered and implemented by the participants only. </li>
    <li>Problem statement will be revealed on spot. </li>
    <li>Only Undergraduate students with a valid college id-card are eligible. </li>
    <li>A team should have exactly 2 members; they need not be from the same institute but should satisfy eligibility for participation. </li>
    <li>Decision of the Organisers and Coordinators is final. Any kind of malpractices will lead to direct disqualification. </li>
    </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactCircuiter').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactCircuiter" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactCircuiter').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Circuiter</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Prajwal Patnaik : 7702453001</li>
    <li>Debottam Sukla : 9447786083 </li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('circuiter')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" style="color: black">Register</button>
  </div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-quarter">
  <div class="w3-card w3-container w3-indigo w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Electromania</h3><br>	
  <img src="../images/logo/electromania.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutElectromania').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutElectromania" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutElectromania').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Electromania</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
     Can’t get enough of electrical circuits? Love to play around with different electronic equipment? Then, Electromania is your thing. Put your electronics geek into test by your active participation.
    <br><br>An electronics based event comprising of quizzes and subsequent task accomplishment that culminates into a finale of designing circuits.
    </p>
    
    <br><br><h3  class="Ab2">Format</h3>
    <ol class="list">
    <li>The event consists of three rounds.</li>
    <li>Round 1 (The prelims) – Put your general electrical knowledge to test in Round 1. Written prelims to test your basics in electrical and electronics. Short listed participants will move on to Round 2.</li>
    <li>Round 2 (Buzzing the Buzzer) – Its time to up the ante and display your swiftness. It will consist of a buzzer round quiz. Participants may expect a fair amount of questions from wide range of fields in electrical and electronics. Selected participants will move on to the Round 3.</li>
    <li>Round 3 (Crack the puzzle) – In this finale, you will have to apply your basics in electronics to solve the puzzle within time limit. </li>
    <li>Further details will be disclosed during the event.</li>
    
    </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 9,000</p>
<!--     <br><br><h3  class="Ab2">Prize Money</h3>
	<ol class="list">
    <li>First Prize: ₹</li>
    <li>Second Prize: ₹ </li>
    </ol>
 -->    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesElectromania').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesElectromania" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesElectromania').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Electromania</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>Each team shall have maximum of two members.</li>
    <li>Use of any electronic devices is strictly prohibited.</li>
    <li>Only undergraduate students are eligible.</li>
    <li>The decision of organizers shall be final.</li>
    <li>Rounds shall be bounded by time limits.</li>
    </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactElectromania').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactElectromania" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactElectromania').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Electromania</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Suvrajit Ghosh : 9447785411</li>
    <li>Subhajit Paul : 7363838775 </li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('electromania')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" style="color: black">Register</button>
  </div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-quarter">
  <div class="w3-card w3-container w3-indigo w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Tarang</h3><br>	
  <img src="../images/logo/tarang.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutTarang').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutTarang" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutTarang').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Tarang</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
Have you tried drawing something and end-up scribbling? Well here is a chance to show your caliber in making no straight line. Just dig into your brain, find a cool design and implement.    </p>
    
    <br><br><h3  class="Ab2">Format</h3>
    <ol class="list">
    <li>Event will have two rounds: Prelims and Finals</li>
    <li>Prelims round will have written questions on three topics: 
	<ul style="padding-left: 20px"><li>Output of a given circuit</li> <li>Designing circuit for given waveform</li> <li>Circuit debugging</li></ul></li>
    <li>Finals round will be on implementation of a given waveform using set of limited components. </li>
    
    </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 6,500</p>
<!--     <br><br><h3  class="Ab2">Prize Money</h3>
	<ol class="list">
    <li>First Prize: ₹</li>
    <li>Second Prize: ₹ </li>
    </ol>
 -->    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesTarang').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesTarang" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesTarang').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Tarang</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>Individual or teams consisting two members can register for the event.</li>
    <li>Any kit from outside or any malpractice in the event will be considered as disqualification of participation. </li>
    <li>Selection in first round will be based on number of attempted questions and time taken.</li>
    <li>Final prize will be on accuracy(40%), quality(40%) and time taken to complete (20%).</li>
    <li>Participant should have valid ID proof.</li>
    </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactTarang').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactTarang" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactTarang').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Tarang</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Subham Saha : 9447784511</li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('tarang')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" style="color: black">Register</button>
  </div>
</div>

<!--   event one ends here -->

</div>
</body>