<!DOCTYPE html>
<html>
<title>Bot in Act | Conscientia 2018</title>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="../images/clogob.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/main.css" />
<script src="../js/main.js"></script>
    <meta name="robots" content="noindex">
<div id="load_screen">
    <img src="../images/clogow.png" id=conspic>
    <div id="loading"></div>
</div>
<link rel="stylesheet" media="screen" href="../css/style.css">
<head>
<style>
.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
</style>
</head>
<body onload="hideloader();">

    <div class="topnav" id="myTopnav">
        <a href="../" class="active"><img src="../images/clogow.png" id="logo" ></img></a>
        <a class="n" href="Aparimit.php">Aparimit</a>
        <a class="n" href="Bot in the act.php"  class="active">Bot In Act</a>
        <a class="n" href="Cyberia.php">Cyberia</a>
        <a class="n" href="Kaleidoscope.php">Kaleidoscope</a>
        <a class="n" href="Mechamorphosis.php">Mechamorphosis</a>
        
        <a class="n" href="Paripath.php">Paripath</a>
        <a class="n" href="Philosophiae.php">Philosophiae</a>
        <a class="n" href="Vihang.php">Vihang</a>
          <a class="n" onclick="document.getElementById('contact').style.display='block'" >LogIn</a>        <div id="contact" class="w3-modal"> 
            <div class="w3-modal-content w3-animate-zoom">
                <div class="w3-container w3-black w3-leftbar">
                   <span onclick="document.getElementById('contact').style.display='none'" class="w3-button w3-display-topright w3-large"><p id="close">x</p></span>
                    <h1 id="Log">LogIn</h1>
                </div>
                <div class="w3-container w3-black w3-leftbar">
                <br>
                <div>
                        <!-- <h2>Login Information</h2> -->
                       
                       <br>
                        <div>
                            <label for="username" id="user">Username</label>
                            <br><br>
                            <input type="text"  class="w3-input w3-padding-5 w3-border-bottom w3-black" name="username" id="username">
                        </div>
                        <br>    
                        <div>
                            <label for="password" id="user">Password</label>
                            <br>
                            <br>
                            <input type="password" class="w3-input w3-padding-5 w3-border-bottom w3-black" name="password" id="password">
                        </div>    
                        <p id="signerr"></p>
                        <button onclick="login()" class="w3-button w3-hover-none w3-tiny w3-black" ><p id="user1">Login</p></button>
                        
                    </div>
                   <p> <a href="../pass.php" target="_blank">Forgot your password?</a> </p> 
                     <p> <a href="../signup.html" target="_blank">Sign Up</a> </p>            
                 </div>
               </div>
              </div> <a class="n" href="javascript:void(0);" style="font-size:20px;color:silver " id="icon" onclick="myFunction()">&#9776;</a>
                </div>



                <div class="w3-display-container w3-animate-opacity">

  <img src="img/robot_android_digital_art_cgi_104320_1920x1080.jpg" alt="boat" style="width:100%;min-height:350px;max-height:400px;"><h1 class="w3-animate-bottom centered titleeve">BOT IN ACT</h1>
  <div class="w3-container w3-display-bottomleft w3-margin-bottom">  
  </div>
</div>	
<div class="w3-row-padding w3-center w3-margin-top">
  <div class="w3-quarter">
    <div class="w3-card w3-container clime w3-margin-top" style="min-height:460px">
    <h3 class="Ab1">Robowars</h3><br>	
    <img src="../images/logo/war of bots icon.png" height="35%" width="35%"></img>
    
     <p class="Ab"><button onclick="document.getElementById('AboutRobowars').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
    </p>
    <div id="AboutRobowars" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('AboutRobowars').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Robowars</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br>
           <p class="Ab">
              Warfare has taken a step into the future. Human soldiers are no longer deployed in war. It’s time for the robots to fight it out. The nation beckons to its brightest minds to build a perfect war machine from limited resources. Can you rise up to the challenge to defend your country? Are you game enough? Conscientia 2k18 brings to you ROBORAGE, a mega event that sets the stage on fire. Bots from all over the nation fight it out here to show who the boss is. Put together your minds, gather ideas and make your own fighting machine. Be ready to face the heat, the sparks and the smoke.
      </p>
     
      <br><br><h3 class="Ab2" >Bot Specification</h3>
      <ol class="list">
      <li>Bot can be wired/wireless. No special points/privilege given to wireless bot.</li>
      <li>Maximum allowed weight of the bot is 15kg.</li>
      <li>The size of the bot must not exceed 40*40*35 cm (All weapons retractable included)</li>
      <li>The max potential difference between any two points should not be more than 24 V AC/DC</li>
      <li>Battery can be on-board /off board (weight will be included if on-board else not).</li>
      <li>Team should bring its own power supply. A 220 V power source can be given for charging the battery, but cannot be used during fight.</li>
      <li>The following things should not be included in the bot in any form: Projectiles Liquids or flame based weapon. Any entanglement device Hydraulics Radio jammers</li>
      <li>All actuators should be electronic.</li>
      <li>A maximum tolerance of 5% can be allowed with regard to size, dimensions and power specifications.</li>
      <li>If any one of the specification is not followed, it will lead to immediate disqualification of the team.</li>
    </ol> 

    <br><br><h3 class="Ab2">Arena</h3>
      <ol class="list">
      <li>Uneven terrain, wedges, bridges, pits can be expected.</li>
      <li>Suggestible length of the wire is 5m according to the arena dimensions.</li>
      <li>Further details will be uploaded later/revealed at the time of event.</li>
      <!-- <li>The max potential difference between any two points should not be more than 24 V AC/DC</li>
      <li>Battery can be on-board /off board (weight will be included if on-board else not).</li>
      <li>Team should bring its own power supply. A 220 V power source can be given for charging the battery, but cannot be used during fight.</li>
      <li>The following things should not be included in the bot in any form: Projectiles Liquids or flame based weapon. Any entanglement device Hydraulics Radio jammers</li>
      <li>All actuators should be electronic.</li>
      <li>A maximum tolerance of 5% can be allowed with regard to size, dimensions and power specifications.</li>
      <li>If any one of the specification is not followed, it will lead to immediate disqualification of the team.</li>
   -->
    </ol> 
      <br><br><h3 class="Ab2">Total Prizes worth more than ₹ 37,000</h3>

<!--           <ol class="list">
              <li>First Prize: ₹</li>
              <li>Second Prize: ₹ </li>
              </ol>
 -->      </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesRobowars').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
    </p><div id="RulesRobowars" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('RulesRobowars').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Robowars</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3 class="Ab2">Rules</h3>
           <ol class="list">
      <li>A team should consist of maximum of 5 members.</li>
      <li>The bot has to push the opponent bot out of the arena to win.</li>
      <li>If both the bots stay in the arena after specified time. The team with more points will be declared winner.</li>
      <li>Only two persons from a team will be allowed near the arena (one operator to control the bot and one to manage the wire).</li>
      <li>Arena should not be damaged by any weapons used by the bot.</li>
      <li>Any team that is not ready when called will be disqualified.</li>
      <li>If the bot is not able to move (position) for 30 sec the opposite team will be declared as winner.</li>
      <li>An interrupt can be called (if there is a technical problem only) by the participant for maximum 2 min to attempt repairs (with appropriate penalty). If not able to repair in given time the bot will lose.</li>
      <li>Only one allowed interrupt per match per team.</li>
      <li>If both bot become immobile then organizers can call for an interrupt or restart the match.</li>
      </ol> 
      </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactRobowars').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
    </p><div id="ContactRobowars" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('ContactRobowars').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Robowars</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3 class="Ab2">Contacts</h3>
           <ol class="list">
      <li>Sidhartha : 9447784712	</li>
      <li>Vamsi : 9447788703 </li>
      </ol>
      </div>
      </div>
  </div>
    <button onclick="event_reg('robowars')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
    </div>
  </div>
  
  <!--   event one ends here -->
  <!--   event1 sarts here copy and paste this code and change the content accordingly -->
  <div class="w3-quarter">
    <div class="w3-card w3-container clime w3-margin-top" style="min-height:460px">
    <h3 class="Ab1">Line Follower</h3><br>	
    <img src="../images/logo/line follower icon.png" height="35%" width="35%"></img>
    
     <p class="Ab"><button onclick="document.getElementById('AboutLineFollower').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
    </p>
    <div id="AboutLineFollower" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('AboutLineFollower').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Line Follower</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br>
           <p class="Ab">
              Robotics events are incomplete without a line follower competition. A simple black line on a white background and your robot must follow it. Easy, right? Here’s the catch. 
              The track is filled with bends and curves.  The task is to build an autonomous robot which is capable of traversing a black line on a white background. The track has bends, curves, T-joints and breaks.
               </p>
       <br><br><h3 class="Ab2">Format</h3>
      <ol class="list">
      <li>A track will be provided for the participants on which the bots have to compete.</li>
      <li>The track will be a simple racing track for line followers and also has obstacles.</li>
      <li>The sample track will be uploaded later.</li>
      </ol>
         <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 20,000</p>

<!--       <br><br><h3 class="Ab2">Prize Money: </h3>
      <ol class="list">
          <li>First Prize: ₹</li>
          <li>Second Prize: ₹ </li>
          </ol> 
 -->    </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesLineFollower').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
    </p><div id="RulesLineFollower" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('RulesLineFollower').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Line Follwer</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3 class="Ab2">Rules</h3>
           <ol class="list">
      <li>Maximum four members are allowed in one team and a member can be a part of one team only. Students from different educational institute can form a team.</li>
      <li>The width of the line will be around 25mm. </li>
      <li>Max Sources potential difference allowed is 20 V. </li>
      <li>Change of batteries and sensors or modifications are allowed but the game is to be re started.</li>
      <li>Any damage caused to the arena due to robot will lead to disqualification. </li>
      <li>Preliminary Round will have smooth lines, sharp turns and curves. </li>
      <li>Final round consists 90 degree turns, junctions, loops and inversion.</li>
      <li>Participants are allowed to have multiple run and best time will be selected.</li>
      <li>Interruptions are allowed but limited.</li>
     </ol> 
   
      <br><br><h3 class="Ab2">Evaluation</h3>
      <ol class="list">
      <li>Distance covered and check points crossed by the bot.</li>
      <li>Time taken to complete the path.</li>
      <li>The decision of juries will be final.</li>
      <li>Rules can be amended by the judges accordingly</li>
        
    </ol> 
     
      <br><br><h3 class="Ab2">Bot Specification</h3>
      <ol class="list">
      <li>Robot should be autonomous with on-board power source.</li>
      <li>The size of the bot should not be exceeding: 250mm * 250mm * 250mm, the maximum weight is 3kgs.</li>
      <li>Robots must not use readymade mechanisms, Lego kits, etc. However readymade sensors and microcontroller kits can be used.</li>
      </ol>
    
    </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactLineFollower').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
    </p><div id="ContactLineFollower" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('ContactLineFollower').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Line Follower</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3 class="Ab2">Contacts</h3>
           <ol class="list">
      <li>Kalepu HarshaNikhita : 8985643191</li>
      <li>R G Sriya : 9535268668</li>
      </ol>
      </div>
      </div>
  </div>
    <button onclick="event_reg('line_follower')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
    </div>
  </div>
  
  <!--   event one ends here -->
  <!--   event1 sarts here copy and paste this code and change the content accordingly -->
  <div class="w3-quarter">
    <div class="w3-card w3-container clime w3-margin-top" style="min-height:460px">
    <h3 class="Ab1">RC Car</h3><br>	
    <img src="../images/logo/rc car icon.png" height="35%" width="35%"></img>
    
     <p class="Ab"><button onclick="document.getElementById('AboutRCCar').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
    </p>
    <div id="AboutRCCar" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('AboutRCCar').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">RC Car</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br>
           <p class="Ab">
              “If everything is under control, you are not going fast enough.”
      <br><br>Whether you’re nine or ninety, if you love cars and enjoy tinkering with things, you will get hours of enjoyment and excitement from RC cars. But there are a lot of things involved in getting to the race, and if you’re new to RC vehicles and RC racing, you’ve probably got a lot of questions.

      Most people don’t realize just how exciting RC vehicles have become—the hobby quality RC cars made and raced today have can get up to speeds of 60 mph and feature suspension systems that can be tuned just like a real car. Perhaps the most exciting part is the wide variety of types of RC vehicles: you can drive a race car, run a monster truck on dirt tracks or even fly a plane!
      
      So this is an opportunity for the people who love making RC machines. Use your skills and make the remote controlled car according to the rules.
      
      </p>
          <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 20,000</p>
    </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesRCCar').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
    </p><div id="RulesRCCar" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('RulesRCCar').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">RC Car</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3 class="Ab2">Rules</h3>
           <ol class="list">
      <li>Machine should fit in a box of dimensions 60 cm x 60 cm x 50 cm (l x b x h) at any moment of time during the race. The external device which is used to control the machine is not included in the size constraint.</li>
      <li>The maximum number of team members is 5.</li>
      <li>Bots made from ready-made kits will be disqualified </li>
      <li>Bots can be wired or wireless, extra points will be given for the wireless bots.</li>
      <li>If one has wired bot, the wire must remain slack at any moment during the race.</li>
      <li>Weight of the bot must not be more than 10kg</li>
      <li>The total voltage should not exceed 24V.</li>
      <li>The event will consist of two rounds.</li>
      <ol class="list">
      <p style="font-family: 'icon3';font-size: 20px;">Round 1:</p><br>
      <li> The teams must complete the course individually in the least possible time. Five teams with the minimum time will be shortlisted for the finals. </li>
      <li>In the first round, for every barrier knocked down, 5 seconds will be added to the final score.</li>
    </ol>  
    
    <ol class="list">
        <p style="font-family: 'icon3';font-size: 20px;">Round 2:</p><br>
        <li> For the finals, the shortlisted participants will have to clear different checkpoints over a total distance of around 30m for which total of 6 penalties will be given, and the one clearing it the earliest in the shortest time and with less penalties shall be awarded as winner. </li>
      </ol>  
    </ol> 
      </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactRCCar').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
    </p><div id="ContactRCCar" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('ContactRCCar').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">RC Car</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3 class="Ab2">Contacts</h3>
           <ol class="list">
      <li>Neelabh Dev : 9447786057</li>
      <li>Sharvi Ghanekar : 9447784091</li>
      </ol>
      </div>
      </div>
  </div>
    <button onclick="event_reg('rc_car')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
    </div>
  </div>
  
  <!--   event one ends here -->
  <!--   event1 sarts here copy and paste this code and change the content accordingly -->
  <div class="w3-quarter">
    <div class="w3-card w3-container clime w3-margin-top" style="min-height:460px">
    <h3 class="Ab1">Amphibot</h3><br>	
    <img src="../images/logo/amphibot icon.png" height="35%" width="35%"></img>
    
     <p class="Ab"><button onclick="document.getElementById('AboutAmphibot').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
    </p>
    <div id="AboutAmphibot" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('AboutAmphibot').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Amphibot</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br>
           <p class="Ab">
              A new planet has been discovered and there are possibilities of very rare and important
              elements. Space agency of your country is calling you to explore the next frontier in the
              universe. Agency needs an exploration robot which can move on both land and water.
              Conscientia ’18 invites you to our amphibot designing competition. Exciting
              prizes await those who prove themselves to be the best. Get ready for the most unforgettable
              and ultimate racing experience!!
              
      </p>
     
      <br><br><h3 class="Ab2">Format</h3>
      <ol class="list">
      <li>Participants have to build an amphibious vehicle (amphibot) which can
          move on land as well as in water.
          </li>
      <li>The participants will individually race their amphibot on a track composed
          of land and deep water pools. The bot should be able to turn on land as well as on water and also complete the track in the least possible time.
          </li>
      <li>The one whose bot successfully completes the entire track in the least
          amount of time(including bonuses and penalties) will be declared the winner.
          </li>
      </ol> 

      <br><br><h3 class="Ab2">Track</h3>
      <ol class="list">
      <li>It will consist partly of land and partly of water.</li>
      <li>Participants are required to observe proper safety precautions by insulating all the electronic
          components.</li>
      <li>The path may have variations in texture as well as geometry (**important)(i.e. there may be turns, banking, unevenness, slipperiness,  sandy, etc.)</li>
      <li>There may be inclined planes, bridges, tunnels, etc..</li>
      <li>There may be some surprise elements in the track which will be disclosed at the time of
          event.
          </li> 
      <li>There may be multiple tracks across the arena; some short and tough, some long but easy.</li>
  
    </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 25,000</p>


<!--       <br><br><h3 class="Ab2">Prize Money:</h3>
      <ol class="list">
          <li>First Prize: ₹</li>
          <li>Second Prize: ₹ </li>
          </ol> 
 -->    </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesAmphibot').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
    </p><div id="RulesAmphibot" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('RulesAmphibot').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Amphibot</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3 class="Ab2" >Rules</h3>
           <ol class="list">
      <li>A team can have a maximum of 5 members.</li>
      <li>In case a team brings multiple bots to the event, they have to declare the competing bot
          before the start of the event. Only one bot will be allowed to compete in the event.
          </li>
      <li>The amphibot should not be more than 30cm*30cm*20cm (length*breadth*height) in its dimensions. That is, it should fit in a box of the same dimensions. Tolerance in dimension up to
          1cm.
           </li>
      <li>The potential difference between any two points of the vehicle must not exceed 15 volts.</li>
      <li>The robot, if controlled by wired transmission is required to have a minimum wire length of 2m.</li>
      <li>Use of internal combustion engines is not allowed. Only electric motors have to be used for power. </li>
      <li>Participants are not allowed to touch the vehicle once it has started. In case of the vehicle getting stuck, they can correct its course(1/2 feet tolerance) with some penalty.</li>
      <li>The amphibot should not, in any way, take the support of the walls or the pool bottom while
          crossing the water pool.
          </li>
      <li>The bot has to clear each checkpoint on the track before going to the next. **If a team chooses to quit before completing the track it is disqualified.</li>
      <li>There is no restriction on the weight of the amphibot. It is up to the participants and their
          engineering judgment to decide about this.
          </li>
      <li>Each participant/group is entitled for a test run* and a first trial. In case a bot encounters a technical snag in the first trail, another chance will be given with some penalty.</li>
      <li>Only top 8 teams are entitled to a second trial and least time among the two trials will be taken into consideration for the final evaluation. In case a bot encounters a technical snag in the second trial, the time of the other trial will be taken into account.</li>
      <li>In the rare event of a tie, the tied teams will be asked to race again in a sudden death
          situation. The timings for the sudden death race will be considered and the earlier timings
          (even though they may be better) will be scrapped. However this is only in the rare event of a
          tie.
          </li>
      <li>Other real time racing rules will be given on-spot and nothing except track would be provided.
          *during the time before the actual event starts
          </li>
      <li>IN ANY CASE THE DECISION OF ORGANIZERS WILL BE FINAL AND BINDING</li>
    </ol> 
      </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactAmphibot').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
    </p><div id="ContactAmphibot" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('ContactAmphibot').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Amphibot</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3 class="Ab2" >Contacts</h3>
           <ol class="list">
      <li>Surya : 7893598035</li>
      <li>Aditya : 9447784055

        </li>
      </ol>
      </div>
      </div>
  </div>
    <button onclick="event_reg('amphibot')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
    </div>
  </div>
  
  <!--   event one ends here -->
  





</div>
</body>