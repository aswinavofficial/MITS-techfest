<!DOCTYPE html>
<html>
<title>Philosophiae | Conscientia 2018</title>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="../images/clogob.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/main.css" />
<script src="../js/main.js"></script>
    <meta name="robots" content="noindex">
<link rel="stylesheet" media="screen" href="../css/style.css">
<div id="load_screen">
    <img src="../images/clogow.png" id=conspic>
    <div id="loading"></div>
</div>
<head>
<style>
.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
</style>
</head>
<body onload="hideloader();">

    <div class="topnav" id="myTopnav">
        <a href="../" class="active"><img src="../images/clogow.png" id="logo" ></img></a>
        <a class="n" href="Aparimit.php">Aparimit</a>
        <a class="n" href="Bot in the act.php">BotInAct</a>
        <a class="n" href="Cyberia.php">Cyberia</a>
        <a class="n" href="Kaleidoscope.php" >Kaleidoscope</a>
        <a class="n" href="Mechamorphosis.php">Mechamorphosis</a>
        
        <a class="n" href="Paripath.php" >Paripath</a>
        <a class="n" href="Philosophiae.php" class="active">Philosophiae</a>
        <a class="n" href="Vihang.php">Vihang</a>
          <a class="n" onclick="document.getElementById('contact').style.display='block'" >LogIn</a>        <div id="contact" class="w3-modal"> 
            <div class="w3-modal-content w3-animate-zoom">
                <div class="w3-container w3-black w3-leftbar">
                   <span onclick="document.getElementById('contact').style.display='none'" class="w3-button w3-display-topright w3-large"><p id="close">x</p></span>
                    <h1 id="Log">LogIn</h1>
                </div>
                <div class="w3-container w3-black w3-leftbar">
                <br>
                <div>
                        <!-- <h2>Login Information</h2> -->
                       
                       <br>
                        <div>
                            <label for="username" id="user">Username</label>
                            <br><br>
                            <input type="text"  class="w3-input w3-padding-5 w3-border-bottom w3-black" name="username" id="username">
                        </div>
                        <br>    
                        <div>
                            <label for="password" id="user">Password</label>
                            <br>
                            <br>
                            <input type="password" class="w3-input w3-padding-5 w3-border-bottom w3-black" name="password" id="password">
                        </div>    
                        <p id="signerr"></p>
                        <button onclick="login()" class="w3-button w3-hover-none w3-tiny w3-black" ><p id="user1">Login</p></button>
                        
                    </div>
                   <p> <a href="../pass.php" target="_blank">Forgot your password?</a> </p> 
                     <p> <a href="../signup.html" target="_blank">Sign Up</a> </p>            
                 </div>
               </div>
              </div> <a class="n" href="javascript:void(0);" style="font-size:20px;color:silver"id="icon" onclick="myFunction()">&#9776;</a>
                </div>

                <div class="w3-display-container w3-animate-opacity">

  <img src="img/philosophiae.jpg" alt="boat" style="width:100%;min-height:350px;max-height:400px;"><h1 class="w3-animate-bottom centered titleeve1">PHILOSOPHIAE</h1>
  <div class="w3-container w3-display-bottomleft w3-margin-bottom">  
  </div>
</div>	
<div class="w3-row-padding w3-center w3-margin-top">
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-third">
  <div class="w3-card w3-container w3-green w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Panchamantra</h3><br>	
  <img src="../images/logo/panchmantra.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutPanchamantra').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutPanchamantra" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutPanchamantra').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Panchamantra</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
            Think and come out with the most simplest and innovative ideas to solve the given
            problems in each level of this bumpy journey. Problems need you to apply elementary
            scientific knowledge, common sense and your ‘out of the box thinking’ ... It gets better
            and better with each increasing level.
            
    </p>
    
    <br><br><h3  class="Ab2">Format</h3>
    <ol class="list">
    <li>Prelims will be written round in which maximum of 20 teams will be selected for the finals.</li>
    <li>The race takes you through 5 different tasks based on the application of
        engineering, science, logic or mathematics etc.
        </li>
    <li>Teams will have to complete a task fully.</li>
    <li>Choose your team wisely... diversity in skill matters. Problems need elementary knowledge of all streams...</li>
    <!-- <li>The participants will be given 10 minutes to present their paper before a panel of judges and around extra 5 minutes for questions and answers as per discretion of judges.</li>
    <li>The team should mention the department under which it chooses to present.</li> -->
    </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 17,500</p>
<!--     <br><br><h3 class="Ab2">Prize Money:  </h3>
    <ol class="list">
            <li>First Prize: ₹</li>
            <li>Second Prize: ₹ </li>
            </ol> 
 -->    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesPanchamantra').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesPanchamantra" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesPanchamantra').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Panchamantra</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>The event is open to all college students with valid ID cards.</li>
    <li>A team can have a maximum of 3 members.</li>
    <li>A person can be part of only one team </li>
    <li>The members of the teams can be from different colleges.
        “If you think you can put science into practice, you are eligible”.
        </li>
    <li>Any valid solutions to the given task will be considered.</li>
    <li>Evaluation will be based on the efficiency of your model, your explanation to the solution and how fast you reach the solution.</li>
    <li>The most innovative and practically viable solution will help score higher.</li>
    <li>The team must complete the round in stipulated time to qualify to next round.</li>
    <li>The next task will be given only on the completion of the first task.</li>
    <li>The decision of the event organizers will be final and binding under all circumstances.</li>
    <li>Participation in malpractices like taking help from the other groups, if caught will be eliminated or disqualified.</li>
    <li>If you still have any doubts regarding the rules, please contact the organisers without hesitation.</li>
    </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactPanchamantra').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactPanchamantra" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactPanchamantra').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Panchamantra</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
     <li>Naman: 8875702722</li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('panchamantra')" class="w3-button w3-xlarge w3-theme w3-hover-teal" style="color: black" title="Go To W3.CSS">Register</button>
  </div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-third">
<div class="w3-card w3-container w3-green w3-margin-top" style="min-height:460px">
<h3 class="Ab1">Image In</h3><br>	
<img src="../images/logo/Screwed.png" height="35%" width="35%"></img>

<p class="Ab"><button onclick="document.getElementById('AboutImageIn').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
</p>
<div id="AboutImageIn" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('AboutImageIn').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Image In</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br>
   <p class="Ab">
      For one eye it is a ray, for the other it as a wave. In spite of this duality it rules the universe. Enthusiasts
      don’t get bewildered by its properties and play around with it to come up with breathtaking marvels.
      Conscientia 2018 gives you an opportunity to bend, merge, scatter and whatever you can do with it to show your attachment with the fastest thing in the material universe.
      
</p>
<!-- <br><br><h3  class="Ab2">Departments</h3>
<ol class="list">
<li>Astronomy and Astrophysics</li>
<li>Mechanical</li>
<li>Electrical/Electronics</li>
<li>Computer Science and Information Technology</li>
<li>Physics</li>
</ol>  -->
<br><br><h3  class="Ab2">Format</h3>
<ol class="list">
<li> There will be a preliminary round followed by the finals.</li>
<li> The prelims will be a written round with questions from basics of optics</li>
<li> The teams selected for the finals will be given a series of tasks wherein they will be required to
    solve the given problem statement using the instruments provided.
    </li>
<li> The teams that complete a given task within the allotted time frame will move to the next
    round.</li>
</ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 6,500</p>
<!-- <br><br><h3 class="Ab2">Prize Money:  </h3>
    <ol class="list">
            <li>First Prize: ₹</li>
            <li>Second Prize: ₹ </li>
            </ol> 
 --></div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesImageIn').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
</p><div id="RulesImageIn" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('RulesImageIn').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Image In</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3  class="Ab2">Rules</h3>
   <ol class="list">
<li>A team may consist of a maximum of 3 members.</li>
<li>The event is open to all college students with valid ID cards.</li>
<li>Use of books, mobile phones will lead to disqualification. </li>
<li>Papers with incorrect formatting shall be sent back for correction, and can be resubmitted only once, after being returned, failing which they shall be deemed as disqualified.</li>
<li>Optical lenses and mirrors will be provided.</li>
<li>The decision of the event organizers will be final and binding under all circumstances.</li>
<!-- <li>The participants can include any type of media (pictures, videos, audio) in their presentation, provided they do not show any controversial clips.</li>
<li>Re-presentation of papers already presented in other competitions / conferences are strictly prohibited. If the team is found to be involved in plagiarism, he/she will be disqualified immediately.</li>
<li>If the candidate fails to meet any one of the above mentioned, he/she will be subjected to disqualification.</li>
<li>Decision of judges will be final and binding on all participants. Any discussions regarding evaluation process at any stage shall not be entertained.</li> -->
</ol> 
</div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactImageIn').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
</p><div id="ContactImageIn" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('ContactImageIn').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">ImageIn</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3  class="Ab2">Image In</h3>
   <ol class="list">
 <li>Kannan: 9497048025</li>
</ol>
</div>
</div>
</div>
<button onclick="event_reg('image_in')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" style="color: black">Register</button>
</div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-third">
<div class="w3-card w3-container w3-green w3-margin-top" style="min-height:460px">
<h3 class="Ab1">How Adam Did It</h3><br>	
<img src="../images/logo/howadam.png" height="35%" width="35%"></img>

<p class="Ab"><button onclick="document.getElementById('AboutHowAdamDidIt').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
</p>
<div id="AboutHowAdamDidIt" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('AboutHowAdamDidIt').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">How Adam Did It</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br>
   <p class="Ab">
      “All of the biggest technological inventions created by man - the airplane, the automobile, the computer
      - says little about his intelligence, but speaks volumes about his laziness.”-Mark Kennedy
      
<br><br>Ever wondered if you were born back then even you too would have came up with some great
inventions. This is your chance to put yourself to test and to show your prowess in designing and
cracking problems.
 
</p>
<!-- <br><br><h3  class="Ab2">Departments</h3>
<ol class="list">
<li>Astronomy and Astrophysics</li>
<li>Mechanical</li>
<li>Electrical/Electronics</li>
<li>Computer Science and Information Technology</li>
<li>Physics</li>
</ol>  -->
<br><br><h3  class="Ab2">Format</h3>
<ol class="list">
<li>There will be two rounds.</li>
<ol class="list">
<p class="Ab">Preliminary round:</p>
  <li > A written round consisting of 10 questions and 2 separate bonus questions (no tie breaker).</li>
  </ol>  
 <ol class="list"> 
<p class="Ab">Second Round</p>
<li>Few teams will be selected for the final.</li>
<li>They will be provided with resources and a problem statement.</li>
<li>The finalists have to make an invention to solve the problem.</li>
<li>In case of a tie, an extra clause may be added to the problem statement by the organizers.</li>
</ol>
</ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 8,000</p>
<!-- <br><br><h3 class="Ab2">Prize Money:  </h3>
    <ol class="list">
            <li>First Prize: ₹</li>
            <li>Second Prize: ₹ </li>
            </ol> 
 --></div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesHowAdamDidIt').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
</p><div id="RulesHowAdamDidIt" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('RulesHowAdamDidIt').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">How Adam Did It</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3  class="Ab2">Rules</h3>
   <ol class="list">
<li>One team should consist of maximum two persons.</li>
<li>Use of unfair means is strictly prohibited and this will lead to disqualification of the team from the
    event. </li>
   </ol>
    <br><br><h3  class="Ab2">Judgement</h3>
   <ol class="list">
<li>The answers of the first round will be limited.</li>
<li>The design problem will be evaluated based on its effectiveness in realizing the problem statement.</li>
<li>For the second round, the score will depend on how closely the design meets the required criteria.
    The participant should keep in mind, the era specified in the problem. If they have used a material
    which is ahead of that time, no points will be awarded.
    </li>
<li>The result of the second round will also depend on the performance of their invention and not on the design. The invention which will perform the best, wins. </li>
<li>The decision of the organisers will be final.</li>
</ol> 
</div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactHowAdamDidIt').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
</p><div id="ContactHowAdamDidIt" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('ContactHowAdamDidIt').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">How Adam Did It</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3  class="Ab2">Contacts</h3>
   <ol class="list">
 <li>Fenil: 9497300032</li>
<!--<li>Samridhi : 9915314098 </li> -->
</ol>
</div>
</div>
</div>
<button onclick="event_reg('how_adam_did_it')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" style="color: black">Register</button>
</div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-half">
<div class="w3-card w3-container w3-green w3-margin-top" style="min-height:460px">
<h3 class="Ab1">Phyknight</h3><br>	
<img src="../images/logo/Phyknight logo.png" height="35%" width="35%"></img>

<p class="Ab"><button onclick="document.getElementById('AboutPhyknight').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
</p>
<div id="AboutPhyknight" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('AboutPhyknight').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Phyknight</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br>
   <p class="Ab">
      “The Knight will rise and challenge the realm of questions in the empire of Physics.”
      -For the love of Irodov-
      
<br><br>This Conscientia, PhyKnight presents an opportunity to delve into the beautiful problems of Physics
which will twist your mind and will make you nostalgic of the good old Olympiad days.
</p>
<!-- <br><br><h3  class="Ab2">Departments</h3>
<ol class="list">
<li>Astronomy and Astrophysics</li>
<li>Mechanical</li>
<li>Electrical/Electronics</li>
<li>Computer Science and Information Technology</li>
<li>Physics</li>
</ol>  -->
<br><br><h3  class="Ab2">Format</h3>
<ol class="list">
<li>Prelims will be a subjective round.</li>
<li>No. of Questions= 8-10.</li>
<li>Time – 1hr</li>
<li>Members allowed- 3</li>
<li>Round 2 will be based on the format of International Physics Olympiad which will consist of both
    theoretical and experimental part.
    </li>
<li>Problem statement will be released on spot and on the day event is conducted.</li>
</ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 7,000</p>
<!-- <br><br><h3 class="Ab2">Prize Money:  </h3>
    <ol class="list">
            <li>First Prize: ₹</li>
            <li>Second Prize: ₹ </li>
            </ol> 
 --></div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesPhyknight').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
</p><div id="RulesPhyknight" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('RulesPhyknight').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Phyknight</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3  class="Ab2">Rules</h3>
   <ol class="list">
<li>The event is open to all college students with valid ID cards.</li>
<li>Any type of cheating will lead to disqualification.</li>
<li>Decision of judges will be final. </li>
<!-- <li>Papers with incorrect formatting shall be sent back for correction, and can be resubmitted only once, after being returned, failing which they shall be deemed as disqualified.</li>
<li>Exceeding of time limit in the second round will invoke negative points.</li>
<li>For every extra minute taken a certain number of points will be deducted from the total. </li>
<li>The participants can include any type of media (pictures, videos, audio) in their presentation, provided they do not show any controversial clips.</li>
<li>Re-presentation of papers already presented in other competitions / conferences are strictly prohibited. If the team is found to be involved in plagiarism, he/she will be disqualified immediately.</li>
<li>If the candidate fails to meet any one of the above mentioned, he/she will be subjected to disqualification.</li>
<li>Decision of judges will be final and binding on all participants. Any discussions regarding evaluation process at any stage shall not be entertained.</li> -->
</ol> 
</div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactPhyknight').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
</p><div id="ContactPhyknight" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('ContactPhyknight').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Phyknight</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3  class="Ab2">Contacts</h3>
   <ol class="list">
 <li>Fenil: 9497300032</li>
<!--<li>Samridhi : 9915314098 </li> -->
</ol>
</div>
</div>
</div>
<button onclick="event_reg('phyknight')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" style="color: black">Register</button>
</div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-half">
<div class="w3-card w3-container w3-green w3-margin-top" style="min-height:460px">
<h3 class="Ab1">Physics Quiz</h3><br>	
<img src="../images/logo/physics quiz logo
.png" height="35%" width="35%"></img>

<p class="Ab"><button onclick="document.getElementById('AboutPhysicsQuiz').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
</p>
<div id="AboutPhysicsQuiz" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('AboutPhysicsQuiz').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Physics Quiz</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br>
   <p class="Ab">
      Even though imagination is more important than knowledge, (in Physics, at least), we ask you to put a check on your knowledge in Physics (and its trivia).
</p>
<br><br><h3  class="Ab2">Format</h3>
<ol class="list">
<li>There will be only one written round.</li>
<li>No. of questions can vary from 15 to 20 (including bonus questions) and can be subjective or objective.</li>
<li>Time- 1 hour.</li>
<li>The questions will judge the general physics knowledge of the team and their ability to apply the basic concepts in real life situations.</li>
<li>Each Question will have a unique answer and will not judge the personal perspective of the team on physics.</li>

</ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 6,000</p>
<!-- <br><br><h3 class="Ab2">Prize Money:  </h3>
    <ol class="list">
            <li>First Prize: ₹</li>
            <li>Second Prize: ₹ </li>
            </ol> 
 --></div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesPhysicsQuiz').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
</p><div id="RulesPhysicsQuiz" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('RulesPhysicsQuiz').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Physics Quiz</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3  class="Ab2">Rules</h3>
   <ol class="list">
<li>The event is open to all college students with valid ID cards.</li>
<li>A team can have a maximum of 2 members.</li>
<li>Use of books, calculators, mobile phones or any other electronic device is strictly prohibited.</li>
<li>Any type of cheating will lead to disqualification.</li>
   </ol>
   <br><br><h3  class="Ab2">Judgement</h3>
   <ol class="list">
<li>Evaluation will be based on the total marks scored by the team.</li>
<li>In case of tie, bonus questions will decide the position of the team.</li>
<li>Decision of the organisers will be final and binding under all circumstances.  </li>
</ol> 
</div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactPhysicsQuiz').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
</p><div id="ContactPhysicsQuiz" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('ContactPhysicsQuiz').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Physics Quiz</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3  class="Ab2">Contacts</h3>
   <ol class="list">
<li>Shivanshi Gupta : 9447787765</li>
<li>Jaya Kalyani KVNS : 9447785014 </li>
</ol>
</div>
</div>
</div>
<button onclick="event_reg('physics_quiz')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" style="color: black">Register</button>
</div>
</div>

</div>
</body>