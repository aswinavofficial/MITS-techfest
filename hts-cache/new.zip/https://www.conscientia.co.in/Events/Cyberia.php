<!DOCTYPE html>
<html>
<title>Cyberia | Conscientia 2018</title>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="../images/clogob.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/main.css" />
    <meta name="robots" content="noindex">
<script src="../js/main.js"></script>
<div id="load_screen">
    <img src="../images/clogow.png" id=conspic>
    <div id="loading"></div>
</div>
<link rel="stylesheet" media="screen" href="../css/style.css">
<head>
<style>
.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
</style>
</head>
<body onload="hideloader();">

    <div class="topnav" id="myTopnav">
        <a href="../" class="active"><img src="../images/clogow.png" id="logo" ></img></a>
        <a class="n" href="Aparimit.php">Aparimit</a>
        <a class="n" href="Bot in the act.php"  class="active">Bot In Act</a>
        <a class="n" href="Cyberia.php">Cyberia</a>
        <a class="n" href="Kaleidoscope.php">Kaleidoscope</a>
        <a class="n" href="Mechamorphosis.php">Mechamorphosis</a>
        
        <a class="n" href="Paripath.php">Paripath</a>
        <a class="n" href="Philosophiae.php">Philosophiae</a>
        <a class="n" href="Vihang.php">Vihang</a>
          <a class="n" onclick="document.getElementById('contact').style.display='block'" >LogIn</a>        <div id="contact" class="w3-modal"> 
            <div class="w3-modal-content w3-animate-zoom">
                <div class="w3-container w3-black w3-leftbar">
                   <span onclick="document.getElementById('contact').style.display='none'" class="w3-button w3-display-topright w3-large"><p id="close">x</p></span>
                    <h1 id="Log">LogIn</h1>
                </div>
                <div class="w3-container w3-black w3-leftbar">
                <br>
                <div>
                        <!-- <h2>Login Information</h2> -->
                       
                       <br>
                        <div>
                            <label for="username" id="user">Username</label>
                            <br><br>
                            <input type="text"  class="w3-input w3-padding-5 w3-border-bottom w3-black" name="username" id="username">
                        </div>
                        <br>    
                        <div>
                            <label for="password" id="user">Password</label>
                            <br>
                            <br>
                            <input type="password" class="w3-input w3-padding-5 w3-border-bottom w3-black" name="password" id="password">
                        </div>    
                        <p id="signerr"></p>
                        <button onclick="login()" class="w3-button w3-hover-none w3-tiny w3-black" ><p id="user1">Login</p></button>
                        
                    </div>
                   <p> <a href="../pass.php" target="_blank">Forgot your password?</a> </p> 
                     <p> <a href="../signup.html" target="_blank">Sign Up</a> </p>            
                 </div>
               </div>
              </div> <a class="n" href="javascript:void(0);" style="font-size:20px;color:silver" id="icon" onclick="myFunction()">&#9776;</a>
                </div>


                <div class="w3-display-container w3-animate-opacity">
   <img src="img/cyberia.jpg" alt="boat" style="width:100%;min-height:350px;max-height:400px;"><h1 class="w3-animate-bottom centered titleeve">CYBERIA</h1>
  <div class="w3-container w3-display-bottomleft w3-margin-bottom">  
  </div>
</div>	
<div class="w3-row-padding w3-center w3-margin-top">
  <div class="w3-quarter">
    <div class="w3-card w3-container cyellow w3-margin-top" style="min-height:460px">
    <h3 class="Ab1">Webbed</h3><br>	
    <img src="../images/logo/webbed.png" height="35%" width="35%"></img>
    
     <p class="Ab"><button onclick="document.getElementById('AboutWebbed').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
    </p>
    <div id="AboutWebbed" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('AboutWebbed').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Webbed</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br>
           <p class="Ab">
              If last year’s ride through the maze of questions that led (and misled) you to more
              intriguing ones fascinated you, here’s a virtual adventure that is guaranteed to
              give the thrill of a lifetime. Webbed is back – with murkier corners, crazier
              questions, innumerable twists and turns and a huge amount of fun! 
      </p>
      
      <br><br><h3  class="Ab2">Format</h3>
      <ol class="list">
           <p class="Ab">
      Your mission should you choose to accept is to navigate from one webpage to
          another, using all of the information available on it. You may need more than just
          a mouse and a keyboard for accomplishing your tasks.</p>
      <li>Lateral Thinking : Two skew lines may or may not meet at only one point. In short, thinking straight
          is a not a good idea.</li>
      <li>Common Sense : Voltaire was right about a lot of things, but never did he hit the nail right on its
          head so hard.</li>
      <li>Sense of Humour : Stop by a question once in a while and smell the roses. See the lighter side of
          things.</li>
      <li>General Knowledge : Neither necessary nor sufficient, it usually helps. GIYF, in any case.</li>
      <li>Perseverance and Integrity : Cheaters never prosper. No tomfoolery of this sort will be tolerated.</li>
      </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 8,000</p>
<!--       <br><br><h3  class="Ab2">Prize Money:</h3>
 --><!--       <ol class="list">
          <li>First Prize: ₹</li>
          <li>Second Prize: ₹ </li>
          </ol>  
 -->    </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesWebbed').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
    </p><div id="RulesWebbed" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('RulesWebbed').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Webbed</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
      <p class="Ab">Keep calm.<br>Stay Tuned!</p>
      </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactWebbed').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
    </p><div id="ContactWebbed" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('ContactWebbed').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Webbed</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3  class="Ab2">Contacts</h3>
           <ol class="list">
      <li> Sneha Gem Mathew : 9497071826</li>
      <li>Bhavana Dinesh :  9496295497</li>
      <li>Amal RS : 9497022600 </li>
      </ol>
      </div>
      </div>
  </div>
    <button onclick="event_reg('webbed')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
    </div>
  </div>
  
  <!--   event one ends here -->
  <!--   event1 sarts here copy and paste this code and change the content accordingly -->
  <div class="w3-quarter">
    <div class="w3-card w3-container cyellow w3-margin-top" style="min-height:460px">
    <h3 class="Ab1">C cubed</h3><br>	
    <img src="../images/logo/Ccube.png" height="35%" width="35%"></img>
    
     <p class="Ab"><button onclick="document.getElementById('AboutCcube').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
    </p>
    <div id="AboutCcube" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('AboutCcube').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">C cubed</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br>
           <p class="Ab">
              Every problem has multiple dimensions. Fancy your chances beyond what is
              certain? Find the best way to dodge the traps. It is not just about what you code;
              it is about how you code. So, can you see beyond the obvious?
      </p>
      
      <br><br><h3  class="Ab2">Format</h3>
      <ol class="list">
      <li>Undergraduate students with valid Identity Card are allowed to participate.</li>
      <li>It is an individual event.</li>
      <!-- <li>Every team needs to send their entries to events@conscientia.co.in in Microsoft Word(.doc/.docx) or printable document(.pdf), in IEEE  or other internationally recognized formats.</li>
      <li>The second round shall consist of a presentation before a bench of judge(s).</li>
      <li>The participants will be given 10 minutes to present their paper before a panel of judges and around extra 5 minutes for questions and answers as per discretion of judges.</li>
      <li>The team should mention the department under which it chooses to present.</li> -->
      </ol> 
      <br><h3  class="Ab2">Judging Criterion</h3>
      <p class="Ab">Based on performance (Time and resources consumed). Each problem with unique weightage in real time.</p>
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 6,500</p>
<!--       <br><br><h3  class="Ab2">Prize Money: </h3>
 --><!--       <ol class="list">
          <li>First Prize: ₹</li>
          <li>Second Prize: ₹ </li>
          </ol>  
 -->      </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesCcube').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
    </p><div id="RulesCcube" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('RulesCcube').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">C cubed</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
      <p class="Ab">Keep calm.<br>Stay Tuned!</p>
      </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactCcube').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
    </p><div id="ContactCcube" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('ContactCcube').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">C Cubed</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3  class="Ab2">Contacts</h3>
           <ol class="list">
      <li>Anant Kumar : 8078981106</li>
      <!-- <li>Samridhi : 9915314098 </li> -->
      </ol>
      </div>
      </div>
  </div>
    <button onclick="event_reg('c_cube')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
    </div>
  </div>
  
  <!--   event one ends here -->
  <!--   event1 sarts here copy and paste this code and change the content accordingly -->
  <div class="w3-quarter">
    <div class="w3-card w3-container cyellow w3-margin-top" style="min-height:460px">
    <h3 class="Ab1">Mathematrix</h3><br>	
    <img src="../images/logo/Mathematrix.png" height="35%" width="35%"></img>
    
     <p class="Ab"><button onclick="document.getElementById('AboutMathematrix').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
    </p>
    <div id="AboutMathematrix" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('AboutMathematrix').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Mathematrix</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br>
           <p class="Ab">
              It is not enough to have a good mind, what's important is to use it well. So if numbers are an innate part of your nature then battle against your likes to find out who is better.
      </p>
      <!-- <br><br><h3  class="Ab2">Format</h3>
      <ol class="list">
      <li>The event consists of 2 rounds.</li>
      <li>The selection in the first round will be based on the paper submitted.</li>
      <li>Every team needs to send their entries to events@conscientia.co.in in Microsoft Word(.doc/.docx) or printable document(.pdf), in IEEE  or other internationally recognized formats.</li>
      <li>The second round shall consist of a presentation before a bench of judge(s).</li>
      <li>The participants will be given 10 minutes to present their paper before a panel of judges and around extra 5 minutes for questions and answers as per discretion of judges.</li>
      <li>The team should mention the department under which it chooses to present.</li>
      </ol>  -->
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 4,000</p>
<!--       <br><br><h3  class="Ab2">Prize Money:</h3>
 --><!--       <ol class="list">
          <li>First Prize: ₹</li>
          <li>Second Prize: ₹ </li>
          </ol>   
 -->    </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesMathematrix').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
    </p><div id="RulesMathematrix" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('RulesMathematrix').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Mathematrix</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3  class="Ab2">Rules</h3>
           <ol class="list">
<li>	The duration of the competition will be of 36 hours (12 hours for First Round(Objective) and 24 hours for the next stage(Subjective))</li>
			   <li>	Individual participation is mandatory and must be done online.</li>
			   <li>	First round will approx. contain 15 questions which will be released individually.</li>
			   <li>	Selection for the second round will be done on time basis.</li>
				<li>	Selected participants for the second round will be mailed/messaged and will be given a specific password.</li>
<li>	Second round will contain 5 questions. Which will be released altogether. Participants need to upload their solutions to the web page within 24 hours in jpg or pdf format.</li>
			   <li>	 Final Results will be announced the next day after the second round.</li>
      </ol> 
      </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactMathematrix').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
    </p><div id="ContactMathematrix" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('ContactMathematrix').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Mathematrix</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3  class="Ab2">Contacts</h3>
           <ol class="list">
<li>Shivansh Verma	:	9447787656</li>
<li>Alakesh Kalita	:	7002480165</li>
<li>Abhishek kr. Sinha	: 9447785314</li>
      <!-- <li>Samridhi : 9915314098 </li> -->
      </ol>
      </div>
      </div>
  </div>
    <button onclick="event_reg('mathematrix')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
    </div>
  </div>
  
  <!--   event one ends here -->
  <!--   event1 sarts here copy and paste this code and change the content accordingly -->
  <div class="w3-quarter">
    <div class="w3-card w3-container cyellow w3-margin-top" style="min-height:460px">
    <h3 class="Ab1">Astronomia</h3><br>	
    <img src="../images/logo/Cosmic Clash.png" height="35%" width="35%"></img>
    
     <p class="Ab"><button onclick="document.getElementById('AboutAstronomia').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
    </p>
    <div id="AboutAstronomia" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('AboutAstronomia').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Astronomia</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br>
           <p class="Ab">
              Knowledge, Glory and eternal Fame lie at the end of the road that lies before you. But be warned, oh wayward Padawan, the path is twisted, riddled with Red herrings and is astronomically complicated, for one wrong turn will leave you stranded in the wrong alleyway of this incomprehensibly complex Universe. Do you have what it takes to scrape your way through space and time, dodging singularities now and then, hyper-jumping between different Universes and finally, accessing the full potential of your brain to crack theCosmic Code? Come find out.
      </p>
      <br><br><h3  class="Ab2">Format</h3>
      <ol class="list">
      <li>Each step of the way, you will be given a challenge which will require you to look deep within all the Universes, both known and unknown.</li>
      <li>Prove yourselves worthy, and you shall pass.</li>
      <li> Hints, like gold during a Gold Rush, will all be right in front of you, but would you see or would you observe and dig?</li>
      <li>You might’ve made the Kessel Run in less than 12 parsecs, but you need to be faster here. </li>
      <li>First one to the finish wins.</li>
      <li>No knowledge of Astronomy (or related subjects) is required, but then again, a little knowledge wouldn’t hurt your chances.</li>
      </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 4,000</p>
<!--       <br><br><h3  class="Ab2">Prize Money: ₹ 3000 * 8 = ₹ 24000 </h3>
      <ol class="list">
          <li>First Prize: ₹</li>
          <li>Second Prize: ₹ </li>
          </ol> 
 -->    
    </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('RulesAstronomia').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
    </p><div id="RulesAstronomia" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('RulesAstronomia').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Astronomia</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3  class="Ab2">Rules</h3>
           <ol class="list">
      <li>Mods are Gods (well, we can dream).</li>
      <li> One operator per ship. If you’re found disobeying this rule, you will be jettisoned.</li>
      <li> Use your ship’s internet systems wisely and use it often. Comb through the interwebs as much you want, and when ready, try your hand at cracking the code in each challenge. (Google, Bing, Yahoo, Quora. Use whichever tickles your fancy!) </li>
      <li>The decision of the event organizers would be final and binding.</li>
      <!-- <li>Exceeding of time limit in the second round will invoke negative points.</li>
      <li>For every extra minute taken a certain number of points will be deducted from the total. </li>
      <li>The participants can include any type of media (pictures, videos, audio) in their presentation, provided they do not show any controversial clips.</li>
      <li>Re-presentation of papers already presented in other competitions / conferences are strictly prohibited. If the team is found to be involved in plagiarism, he/she will be disqualified immediately.</li>
      <li>If the candidate fails to meet any one of the above mentioned, he/she will be subjected to disqualification.</li>
      <li>Decision of judges will be final and binding on all participants. Any discussions regarding evaluation process at any stage shall not be entertained.</li> -->
      </ol> 
      </div>
      </div>
  </div>
  <p class="Ab"><button onclick="document.getElementById('ContactAstronomia').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
    </p><div id="ContactAstronomia" class="w3-modal">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-black w3-display-container">
          <span onclick="document.getElementById('ContactAstronomia').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
          <h1 style="font-family:'icon1'; font-size:38px;">Astronomia</h1>
        </div>
        <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
            <br><br><h3  class="Ab2">Contacts</h3>
           <ol class="list">
      <li>B.S.Bharath Saiguhan: 9447787457</li>
      <li>Aashka Oza: 9447785932</li>
      </ol>
      </div>
      </div>
  </div>
    <button onclick="event_reg('astronomia')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
    </div>
  </div>
  
  <!--   event one ends here -->
  
  
  
  
  
</div>
</body>