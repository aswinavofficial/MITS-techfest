<!DOCTYPE html>
<html>
<title>Mechamorphosis | Conscientia 2018</title>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="../images/clogob.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/main.css" />
    <meta name="robots" content="noindex">
<script src="../js/main.js"></script>

<div id="load_screen">
        <img src="../images/clogow.png" id=conspic>
        <div id="loading"></div>
    </div>
<link rel="stylesheet" media="screen" href="../css/style.css">

<head>
<style>
.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
</style>
</head>
<body onload="hideloader();">

    <div class="topnav" id="myTopnav">
            <a href="../" class="active"><img src="../images/clogow.png" id="logo" ></img></a>
            <a class="n" href="Aparimit.php">Aparimit</a>
            <a class="n" href="Bot in the act.php"  class="active">Bot In Act</a>
            <a class="n" href="Cyberia.php">Cyberia</a>
            <a class="n" href="Kaleidoscope.php">Kaleidoscope</a>
            <a class="n" href="Mechamorphosis.php">Mechamorphosis</a>
            
            <a class="n" href="Paripath.php">Paripath</a>
            <a class="n" href="Philosophiae.php">Philosophiae</a>
            <a class="n" href="Vihang.php">Vihang</a>
          <a class="n" onclick="document.getElementById('contact').style.display='block'" >LogIn</a>        <div id="contact" class="w3-modal"> 
            <div class="w3-modal-content w3-animate-zoom">
                <div class="w3-container w3-black w3-leftbar">
                   <span onclick="document.getElementById('contact').style.display='none'" class="w3-button w3-display-topright w3-large"><p id="close">x</p></span>
                    <h1 id="Log">LogIn</h1>
                </div>
                <div class="w3-container w3-black w3-leftbar">
                <br>
                <div>
                        <!-- <h2>Login Information</h2> -->
                       
                       <br>
                        <div>
                            <label for="username" id="user">Username</label>
                            <br><br>
                            <input type="text"  class="w3-input w3-padding-5 w3-border-bottom w3-black" name="username" id="username">
                        </div>
                        <br>    
                        <div>
                            <label for="password" id="user">Password</label>
                            <br>
                            <br>
                            <input type="password" class="w3-input w3-padding-5 w3-border-bottom w3-black" name="password" id="password">
                        </div>    
                        <p id="signerr"></p>
                        <button onclick="login()" class="w3-button w3-hover-none w3-tiny w3-black" ><p id="user1">Login</p></button>
                        
                    </div>
                   <p> <a href="../pass.php" target="_blank">Forgot your password?</a> </p> 
                     <p> <a href="../signup.html" target="_blank">Sign Up</a> </p>            
                 </div>
               </div>
              </div> <a class="n" href="javascript:void(0);" style="font-size:20px;color:silver "id="icon" onclick="myFunction()">&#9776;</a>
                </div>

                <div class="w3-display-container w3-animate-opacity">

  <img src="img/mecamorphosis.jpg" alt="boat" style="width:100%;min-height:350px;max-height:400px;"><h1 class="w3-animate-bottom centered titleeve1">MECHAMORPHOSIS</h1>
  <div class="w3-container w3-display-bottomleft w3-margin-bottom">  
  </div>
</div>	
<div class="w3-row-padding w3-center w3-margin-top">
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-third">
  <div class="w3-card w3-container cred w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Machinist</h3><br>	
  <img src="../images/logo/Machinist.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutMachinist').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutMachinist" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutMachinist').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Machinist</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
            Does the sound of metal meeting metal excite you? Do you find the sparks of welding riveting?
            Here is a platform for you to test you machinist skills.
             
    </p>
    <!-- <br><br><h3 class="Ab2">Departments</h3>
    <ol class="list">
    <li>Astronomy and Astrophysics</li>
    <li>Mechanical</li>
    <li>Electrical/Electronics</li>
    <li>Computer Science and Information Technology</li>
    <li>Physics</li>
    </ol>  -->
    <br><br><h3 class="Ab2">Format</h3>
    <ol class="list">
    <li>	It consists of 2 rounds.</li>
    <li>	1st round will be a written prelim in which questions on various basic manufacturing
        processes, theory of machines, engineering graphics will be asked. </li>
    <li>2nd round will be a practical round in which, the participants will be given a drawing of
        the component to be made and they need to make the component on the given
        machine.
        </li>
    <!-- <li>The second round shall consist of a presentation before a bench of judge(s).</li>
    <li>The participants will be given 10 minutes to present their paper before a panel of judges and around extra 5 minutes for questions and answers as per discretion of judges.</li>
    <li>The team should mention the department under which it chooses to present.</li> -->
    </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 8,500</p>
<!--     <br><br><h3 class="Ab2">Prize Money:  </h3>
    <ol class="list">
            <li>First Prize: ₹</li>
            <li>Second Prize: ₹ </li>
            </ol>   
 --></div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesMachinist').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesMachinist" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesMachinist').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Machinist</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3 class="Ab2">Rules</h3>
         <ol class="list">
    <li>Team should consist of maximum 2 members.</li>
    <li>The team members can be from different colleges.</li>
    <li>Participants must stick to the guidelines given. </li>
    <li>Participants must take care that their activity does not physically harm other
        participants in the Hall.</li>
    <li>Use of any material not provided by the organizers is strictly prohibited. Participants
        doing so will be disqualified.
        </li>
    <li>Scoring patterns will be mentioned at the time of the event </li>
    <li>This event is open to all college students with valid ID cards.</li>
    <li>The decision of the event organizers will be final and binding under all circumstances.</li>
    <!-- <li>If the candidate fails to meet any one of the above mentioned, he/she will be subjected to disqualification.</li>
    <li>Decision of judges will be final and binding on all participants. Any discussions regarding evaluation process at any stage shall not be entertained.</li> -->
    </ol> 
    <br><br><h3 class="Ab2">Evaluation</h3>
    <ol class="list">
<li>1st round: Each question will carry some marks and based on the maximum marks
    obtained, the top 5 teams will be selected for the 2nd round.
    </li>
<li>2nd round: Based on quality and accuracy of the component made, marks will be
    awarded.
    </li>
<!-- <li>If the candidate fails to meet any one of the above mentioned, he/she will be subjected to disqualification.</li>
<li>Decision of judges will be final and binding on all participants. Any discussions regarding evaluation process at any stage shall not be entertained.</li> -->
</ol> 

    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactMachinist').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactMachinist" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactMachinist').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Machinist</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3 class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Dibya Kanti Golui : 9447784512</li>
    <!-- <li>Samridhi : 9915314098 </li> -->
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('machinist')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-third">
<div class="w3-card w3-container cred w3-margin-top" style="min-height:460px">
<h3 class="Ab1">Screwed</h3><br>	
<img src="../images/logo/Screwed.png" height="35%" width="35%"></img>

<p class="Ab"><button onclick="document.getElementById('AboutScrewed').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
</p>
<div id="AboutScrewed" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('AboutScrewed').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Screwed</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br>
   <p class="Ab">
      Basically an Assemble-Disassemble game in which you have to break your head to
      survive. Conscientia 2018 gives you the opportunity to play with screws , drivers
      and many other tools. So get up and get ready to face the challenge and to
      unscrew the Screwed.
      </p>

<br><br><h3 class="Ab2">Format</h3>
<ol class="list">
<li>This event comprises of three rounds.</li>
<li>This is an individual event.</li>
<li>The participant has to pick up a chit from a lot by which the participant will be
    assigned a device.
    </li>
<li>The first round is an elimination round, in the next rounds the participant has
    to find number 1 to 5 that are hidden at different places inside the device, the
    participants have to find any three parts at level 2,all five at level 3 and in addition
    to disassembling, the participant has to identify a working mechanism.
    </li>
<li>For every 15 participants in the first round, 5 participants will be advanced to
    the next round, and out of that five 3 will advance to round 3.
    </li>
<li>The third round will be conducted between all the participants that will reach
    third round and a winner will be selected.
    </li>
    <li>For finding the given parts or hints, they’ll have to disassemble the device
        properly, and search with keen observation, thoroughness.
        </li>
    <li>After finding the three/five spots, they’ll have to reassemble the device back
        perfectly, failing which will disqualify them.
        </li>
    <li>Use of unfair means is strictly prohibited and this will lead to disqualification of
        the participant from the event.
        
        </li>
  </ol>
  
  <br><br><h3 class="Ab2">Evaluation</h3>
  <ol class="list">
<li>In the first round after the participant is allotted a device he will be given 3
    minutes time for disassembly and 3 minutes to re-assemble the device back.</li>
<li>In the first round for every part the participant disassembles he/she will be
    given 5 points, if the participant fails to reassemble the given parts in given 3
    minutes of time and takes extra time for every 30 seconds 5 points will be
    deducted; in case if the participant wants to stop reassembly then for each part
    he/she did not reassemble 3 points will be deducted.</li>
<li>In round 2 the participant will be given 5 minutes time to find the 3 numbers
    given to him/her and 3 minutes to reassemble the parts back, for every correct
    number the participant finds he will be awarded 5 points; if the participant fails to
    reassemble all the parts in 3 min and takes extra time for every 30 seconds 5
    points will be deducted and in case the participant chooses to stop after 3
    minutes without reassembling all the parts 3 points per part will be deducted.
    </li>
<li>In round 3 the participant will be given 5 minutes to find all the 5 five numbers,
    for every number he/she gets 5 points, they will be given 3 minutes of reassembly
    time and for every 30 seconds extra time taken 5 points will be deducted, in caseif the participant wishes to stop reassembly for each part he/she fails to
    reassemble 3 points will be deducted.
    </li>
</ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 6,500</p>

<!-- <br><br><h3 class="Ab2">Prize Money:  </h3>
    <ol class="list">
            <li>First Prize: ₹</li>
            <li>Second Prize: ₹ </li>
            </ol> 
 --></div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesScrewed').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
</p><div id="RulesScrewed" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('RulesScrewed').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Screwed</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3 class="Ab2">Rules</h3>
   <ol class="list">
<li>One person is allowed to participate only once.</li>
<li>In case of a tie levels, participant with least time in completing the task shall be
    declared as the winner.
    </li>
<li>After finding every number/clue/answer, the participant must report to the
    concerned volunteer/organizer.
     </li>
<li>Decision of organizers shall be final and binding.</li>
<!-- <li>Exceeding of time limit in the second round will invoke negative points.</li>
<li>For every extra minute taken a certain number of points will be deducted from the total. </li>
<li>The participants can include any type of media (pictures, videos, audio) in their presentation, provided they do not show any controversial clips.</li>
<li>Re-presentation of papers already presented in other competitions / conferences are strictly prohibited. If the team is found to be involved in plagiarism, he/she will be disqualified immediately.</li>
<li>If the candidate fails to meet any one of the above mentioned, he/she will be subjected to disqualification.</li>
<li>Decision of judges will be final and binding on all participants. Any discussions regarding evaluation process at any stage shall not be entertained.</li> -->
</ol> 
</div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactScrewed').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
</p><div id="ContactScrewed" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('ContactScrewed').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Screwed</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3 class="Ab2">Contacts</h3>
   <ol class="list">
<li>Uttam :9447784296</li>
<li>Mayank:  9447784436</li>
<!-- <li>Samridhi : 9915314098 </li> -->
</ol>
</div>
</div>
</div>
<button onclick="event_reg('screwed')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
</div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-third">
<div class="w3-card w3-container cred w3-margin-top" style="min-height:460px">
<h3 class="Ab1">Bridge Making</h3><br>	
<img src="../images/logo/Bridge making.png" height="35%" width="35%"></img>

<p class="Ab"><button onclick="document.getElementById('AboutBridgeMaking').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
</p>
<div id="AboutBridgeMaking" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('AboutBridgeMaking').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Bridge Making</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br>
   <p class="Ab">
      “We build too many walls and not enough bridges.”
      -Isaac Newton
      
<br><br>Bridges not only serve the purpose of bringing people together, they are the marvels of Engineering and Architecture. Since ancient times human beings have constructed wonderful bridges which are admired time and again. If you have a great imagination and innovative skills, opportunity is waiting for you. Apply your Engineering skills and design the world’s finest model bridge.
</p>
<!-- <br><br><h3 class="Ab2">Departments</h3>
<ol class="list">
<li>Astronomy and Astrophysics</li>
<li>Mechanical</li>
<li>Electrical/Electronics</li>
<li>Computer Science and Information Technology</li>
<li>Physics</li>
</ol>  -->
<br><br><h3 class="Ab2">Format</h3>
<ol class="list">
<li>Each team will be given materials required to build a stable bridge which can withstand the maximum load in the given time.</li>
<!-- <li>The selection in the first round will be based on the paper submitted.</li>
<li>Every team needs to send their entries to events@conscientia.co.in in Microsoft Word(.doc/.docx) or printable document(.pdf), in IEEE  or other internationally recognized formats.</li>
<li>The second round shall consist of a presentation before a bench of judge(s).</li>
<li>The participants will be given 10 minutes to present their paper before a panel of judges and around extra 5 minutes for questions and answers as per discretion of judges.</li>
<li>The team should mention the department under which it chooses to present.</li> -->
</ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 8,500</p>
<!-- <br><br><h3 class="Ab2">Prize Money:  </h3>
    <ol class="list">
            <li>First Prize: ₹</li>
            <li>Second Prize: ₹ </li>
            </ol> 
 --></div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesBridgeMaking').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
</p><div id="RulesBridgeMaking" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('RulesBridgeMaking').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Bridge Making</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3 class="Ab2">Rules</h3>
   <ol class="list">
<li>A team can have a maximum of 3 members.</li>
<li>Every team member must have a valid college ID.</li>
<li>Time limit: 3 hrs.</li>
<li>A team cannot use any items other than what will be provided.</li>
<li>Violation of any of the above rules will lead to immediate disqualification.  </li>
<!-- <li>For every extra minute taken a certain number of points will be deducted from the total. </li>
<li>The participants can include any type of media (pictures, videos, audio) in their presentation, provided they do not show any controversial clips.</li>
<li>Re-presentation of papers already presented in other competitions / conferences are strictly prohibited. If the team is found to be involved in plagiarism, he/she will be disqualified immediately.</li>
<li>If the candidate fails to meet any one of the above mentioned, he/she will be subjected to disqualification.</li>
<li>Decision of judges will be final and binding on all participants. Any discussions regarding evaluation process at any stage shall not be entertained.</li> -->
</ol> 
<br><br><h3 class="Ab2">Evaluation</h3>
  <ol class="list">
<li>The bridge must follow the given dimensional constraints. These constraints will be provided on the spot.</li>
<li>It will be loaded to destruction by applying load at the center which will be gradually increased. The maximum load it sustains without failure will be the judging criteria.</li>
<li>In case of tie, the engineering viewpoint will be taken into consideration
    The decision of the judges and organizers will be final and binding.</li>

</ol> 


</div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactBridgeMaking').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
</p><div id="ContactBridgeMaking" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('ContactBridgeMaking').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Bridge Making</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3 class="Ab2">Contacts</h3>
   <ol class="list">
<li>Suvrajit Ghosh : 9447785411</li>
<li>Aalokeparno  Dhar : 9447784122 </li>
</ol>
</div>
</div>
</div>
<button onclick="event_reg('bridge_making')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
</div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-third">
<div class="w3-card w3-container cred w3-margin-top" style="min-height:460px">
<h3 class="Ab1">Contraption</h3><br>	
<img src="../images/logo/Contraption.png" height="35%" width="35%"></img>

<p class="Ab"><button onclick="document.getElementById('AboutContraption').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
</p>
<div id="AboutContraption" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('AboutContraption').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Contraption</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br>
   <p class="Ab">
      There’s nothing like the satisfaction of a plan falling into place. “Contraptions” is your chance to
      invoke your creativity and come up with your own grand plan to build a Rube Goldberg
      machine
  </p>
<!-- <br><br><h3 class="Ab2">Contraption</h3>
<ol class="list">
<li>Astronomy and Astrophysics</li>
<li>Mechanical</li>
<li>Electrical/Electronics</li>
<li>Computer Science and Information Technology</li>
<li>Physics</li>
</ol>  -->

<br><br><h3 class="Ab2">Format</h3>
<ol class="list">
<li>The final task is to spread honey over a slice of bread and cover it up with another slice of bread.
    The bread and the honey will be provided on the spot. Participants are required to bring ALL the
    materials required for building their contraption other than the materials provided by the organisers.
    </li>
<li>A preparation time of 3 hrs will be given and run time should not exceed 7 minutes including the
    final action.
    </li>
<li>A maximum space of 10ftX10ft will be provided per team.</li>
<li>One power plug point will be provided per team.</li>
<li>In case of a tie, the contraption with innovative ideas and more number of steps in the given time will be considered as a winner.</li>
<li>Maximum of 2 trials will be allowed per team out of which the best will be chosen.</li>
<li>Teams will have 3 minutes before the first run to explain their contraption.</li>
<li>In case a contraption gets stuck during the run, then with the permission of the Judge(s), one of the participants will be allowed to intervene (with a penalty).</li>
<li>Explosives and hazardous materials are STRICTLY NOT ALLOWED.</li>
<li>Any intentional or unintentional damage to other team's machine will result in an immediate
    disqualification.
    </li>
    <li>Decision of the Judges will be final and binding</li>
</ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 16,000</p>
<!-- <br><br><h3 class="Ab2">Prize Money:  </h3>
    <ol class="list">
            <li>First Prize: ₹</li>
            <li>Second Prize: ₹ </li>
            </ol> 
 --></div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesContraption').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
</p><div id="RulesContraption" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('RulesContraption').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Contraption</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3 class="Ab2">Rules</h3>
   <ol class="list">
<li>Run-time will not be a factor in the Evaluation.</li>
<li>Final score will be decided entirely by the Judges based on the following criteria.
    INNOVATION (20%)</li>
<li>Entirely upto the judges to decide qualitatively. Depending on ingenuity of the Design.
    NUMBER OF STEPS (40%)
    </li>
<li>A step is defined as anything which starts with a trigger (eg : Motion Transfer, Energy Transfer,
    Chemical Reactions) from a previous step and results in an action. Similar or identical steps will be
    counted as one.(eg : 1000 falling dominos on a table will be counted as a single step).
    PARALLEL ROUTES (5%)
    </li>
<li>Step which has actions occurring in parallel and ends in the same trigger.
    PERFECT RUN(No Interventions) (20%)
     </li>
<li>First Intervention will reduce 5% and every subsequent one will reduce 2% each.
    FINAL ACTION OF MACHINE(10%)
    </li>
<li>10% marks will be allotted for completion of the task that is given.
    AESTHETICALLY PLEASING DESIGNS (5%)
    </li>
<li>Qualitatively decided by the judges based on the best usage of the materials.</li>
<!-- <li>Decision of judges will be final and binding on all participants. Any discussions regarding evaluation process at any stage shall not be entertained.</li> -->
</ol> 
</div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactContraption').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
</p><div id="ContactContraption" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('ContactContraption').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Contraption</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3 class="Ab2">Contacts</h3>
   <ol class="list">
<li>Abhijit : 9400490424</li>
<li>Ravi Shankar : 9447784858</li>
</ol>
</div>
</div>
</div>
<button onclick="event_reg('contraption')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
</div>
</div>

<!--   event one ends here -->
<!--   event1 sarts here copy and paste this code and change the content accordingly -->
<div class="w3-third">
<div class="w3-card w3-container cred w3-margin-top" style="min-height:460px">
<h3 class="Ab1">Cad</h3><br>	
<img src="../images/logo/CAD drwaing.png" height="35%" width="35%"></img>

<p class="Ab"><button onclick="document.getElementById('AboutCad').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
</p>
<div id="AboutCad" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('AboutCad').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Cad</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br>
   <p class="Ab">
      Although we perceive the world around us in 3 dimensions, the engineering aspect begins only when an object is seen on paper, i.e., projected. We as engineers realize how crucial drawings are; it is now time to establish how scrutinous you are about it. 
</p>
<!-- <br><br><h3 class="Ab2">Departments</h3>
<ol class="list">
<li>Astronomy and Astrophysics</li>
<li>Mechanical</li>
<li>Electrical/Electronics</li>
<li>Computer Science and Information Technology</li>
<li>Physics</li>
</ol>  -->
<br><br><h3 class="Ab2">Format</h3>
<ol class="list">
<li>There will be TWO rounds: </li>
<ul>
	<li>Pen &amp; Paper Test</li>
	<li>Part design in AutoCAD (version 2009 &amp; above) &amp; Mechanical assembly Design in CATIA </li>
</ul>
<li>Part 1 involves basic questions related to Engineering drawings, AutoCAD, and CATIA.</li>
<li>Part 2 will involve only the reproducing 2D projections of the given 3D figures on the given template &amp; assembly of a working real life mechanism, provided along with the necessary metrological instruments.</li>
</ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 7,000</p>
</div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesCad').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
</p><div id="RulesCad" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('RulesCad').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Cad</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3 class="Ab2">Rules</h3>
    <ol class="list">
      <p class="Ab">Part 1 </p>
		<li>Maximum time given will be 1 hrs.</li>
		<li>Involves basic questions related to Engineering drawings, AutoCAD, and CATIA.</li>
	</ol>
<ol class="list">
<p class="Ab">Part 2 - Maximum time is 3 hours, but completion ahead of time will invite more credits.</p>
    <li>Correctness of each projection</li>
    <li>Exactness of dimensions</li>
    <li>Presence of appropriate drawing lines</li>
    <li>Completion of drawing</li>
    <li>Working of mechanism</li>
    <li>Exactness of dimensions</li>
</ol>
      <p class="Ab">All decisions of the judges are final and binding.</p>
<!-- <li>The participants can include any type of media (pictures, videos, audio) in their presentation, provided they do not show any controversial clips.</li>
<li>Re-presentation of papers already presented in other competitions / conferences are strictly prohibited. If the team is found to be involved in plagiarism, he/she will be disqualified immediately.</li>
<li>If the candidate fails to meet any one of the above mentioned, he/she will be subjected to disqualification.</li>
<li>Decision of judges will be final and binding on all participants. Any discussions regarding evaluation process at any stage shall not be entertained.</li> -->
</div>
</div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactCad').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
</p><div id="ContactCad" class="w3-modal">
<div class="w3-modal-content w3-animate-zoom">
<div class="w3-container w3-black w3-display-container">
  <span onclick="document.getElementById('ContactCad').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
  <h1 style="font-family:'icon1'; font-size:38px;">Cad</h1>
</div>
<div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
    <br><br><h3 class="Ab2">Contacts</h3>
   <ol class="list">
    <li>Dibya Kanti Golui : 9447784512</li>
<!-- <li>Samridhi : 9915314098 </li> -->
</ol>
</div>
</div>
</div>
<button onclick="event_reg('cad')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
</div>
</div>






<div class="w3-third">
    <div class="w3-card w3-container cred w3-margin-top" style="min-height:460px">
    <h3 class="Ab1">Junkyard Wars</h3><br>	
    <img src="../images/logo/Junkyard Wars.png" height="35%" width="35%" style="border-radius:100%;"></img>
    
    <p class="Ab"><button onclick="document.getElementById('AboutJunkyard').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
    </p>
    <div id="AboutJunkyard" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
    <div class="w3-container w3-black w3-display-container">
      <span onclick="document.getElementById('AboutJunkyard').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
      <h1 style="font-family:'icon1'; font-size:38px;">Junkyard Wars</h1>
    </div>
    <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
        <br>
       <p class="Ab">
          Are your thoughts creative enough to create wonders? If yes, then this is the right platform for you to show off your caliber and skills! Nothing is a waste in the eyes of a mechanical
          engineer! Utilize anything and everything in the junkyard to succeed in your mission. Learn to
          improvise and innovate to beat the other teams. There will be three rounds to test your
          creativity and skills. Additional rules will be provided at the beginning of each round. So buckle
          up for a thrill ride!
          
      </p>
    <!-- <br><br><h3 class="Ab2">Contraption</h3>
    <ol class="list">
    <li>Astronomy and Astrophysics</li>
    <li>Mechanical</li>
    <li>Electrical/Electronics</li>
    <li>Computer Science and Information Technology</li>
    <li>Physics</li>
    </ol>  -->
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 27,000</p>
    
<!--     <br><br><h3 class="Ab2">Prize Money:  </h3>
    <ol class="list">
            <li>First Prize: ₹</li>
            <li>Second Prize: ₹ </li>
            </ol> 
 -->    </div>
    </div>
    </div>
    <p class="Ab"><button onclick="document.getElementById('RulesJunkyard').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
    </p><div id="RulesJunkyard" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
    <div class="w3-container w3-black w3-display-container">
      <span onclick="document.getElementById('RulesJunkyard').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
      <h1 style="font-family:'icon1'; font-size:38px;">Junkyard Wars</h1>
    </div>
    <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
       
    <br><br><h3 class="Ab2">Format</h3>
    <ol class="list">
        <li>Each team consists of maximum of 5 members. The event consists of three rounds: </li>
      
     <ol class="list">
        <p class="Ab">Part 1 </p>
 <li>The prelims paper will be theory-based testing the general aptitude of the teams (some of them would challenge you technically).</li>
 <li>Questions will be based on logical reasoning and some practical problems.</li>
 <li>The selection of the teams will be based on the marks scored in the test.</li>
 </ol>
 <ol class="list">
 <p class="Ab">Part 2</p>
 
 <li>This round is an application and time-based round which would definitely test your mechanical creativity and improvising skills.</li>
 <li>Teams will be given a task which has to be completed within the allocated time period.</li>
 <li>Points would be deducted in case of time delay of failure of the device/mechanism.</li>
 <li>Other rules will be specified during the competition.</li>
 </ol>
 <ol class="list">
 <p class="Ab">Part 3 </p>
 
 <li>The problem statement of the final task will be specified at the commencement of the final round. The finalists would be asked to make a machine as per the problem statement given.</li>
 <li>It will also contain a list of machine parts and other components available in the junkyard. If needed the teams will be allowed to visit the junkyard site to check what components can be of their use.</li>
 <li>The teams will also be given a certain amount of virtual money. Each and every part available in the junkyard will cost a certain amount of money.</li>
 <li>The teams then have to give a rough estimate of the list of components they will require and will have to ensure that the total cost of all the components falls within the virtual money provided to them.</li>
 <li>The teams then have to submit their respective design and its specifications to the organizers.</li>
 <li>They will have to build the machine they designed by buying the required components from the junkyard.</li>
 <li>The making of the machine will involve tasks like welding, building electronic connections, carpentry work etc. For such works help can be provided if needed. (E.g.: Welding of rods)</li>



 <ol class="list">
    <p class="Ab">Final Showdown</p>
    
    <li>After all the teams have built their machines, there will be a head-on competition between all the machines.</li>
    <li>The machine which excels this round will be declared as the winner. The winning criteria would be specified during the showdown.</li>
    <li>No part of prototype should consist of foreign element, i.e. the one outside the domain of the junk
        provided.
        </li>
    <li>It is recommended that you keep the physical exertion of the final round in mind while choosing your team mates. Teams cannot be changed between rounds.</li>
    <li>Participants need to have a basic idea about operational precautions.</li>
    <li>In case of any misconduct, decision of the event organizers shall be final and binding.</li>
 </ol>
 
 <li>All decisions of the judges/ are final and binding. </li>
 <!-- <li>The participants can include any type of media (pictures, videos, audio) in their presentation, provided they do not show any controversial clips.</li>
 <li>Re-presentation of papers already presented in other competitions / conferences are strictly prohibited. If the team is found to be involved in plagiarism, he/she will be disqualified immediately.</li>
 <li>If the candidate fails to meet any one of the above mentioned, he/she will be subjected to disqualification.</li>
 <li>Decision of judges will be final and binding on all participants. Any discussions regarding evaluation process at any stage shall not be entertained.</li> -->
 </ol> 
    </div>
    </div>
    </div>
    <p class="Ab"><button onclick="document.getElementById('ContactJunkyard').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
    </p><div id="ContactJunkyard" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
    <div class="w3-container w3-black w3-display-container">
      <span onclick="document.getElementById('ContactJunkyard').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
      <h1 style="font-family:'icon1'; font-size:38px;">JUNKYARD</h1>
    </div>
    <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
        <br><br><h3 class="Ab2">Contacts</h3>
       <ol class="list">
    <li>Jacob  : 9496481043</li>
    <li>Anant  : 9711101451</li>
    </ol>
    </div>
    </div>
    </div>
    <button onclick="event_reg('junkyardwars')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
    </div>
    </div>
    











</div>
</body>