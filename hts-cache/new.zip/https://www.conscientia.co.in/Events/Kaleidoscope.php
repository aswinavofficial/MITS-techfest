<!DOCTYPE html>
<html>
<title>Kaleidoscope | Conscientia 2018</title>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="../images/clogob.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/main.css" />
<script src="../js/main.js"></script>
    <meta name="robots" content="noindex">
<link rel="stylesheet" media="screen" href="../css/style.css">
<div id="load_screen">
    <img src="../images/clogow.png" id=conspic>
    <div id="loading"></div>
</div>
<head>
<style>
.centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
</style>
</head>
<body onload="hideloader()">  
    <div class="topnav" id="myTopnav">
        <a href="../" class="active"><img src="../images/clogow.png" id="logo" ></img></a>
        <a class="n" href="Aparimit.php">Aparimit</a>
        <a class="n" href="Bot in the act.php"  class="active">Bot In Act</a>
        <a class="n" href="Cyberia.php">Cyberia</a>
        <a class="n" href="Kaleidoscope.php">Kaleidoscope</a>
        <a class="n" href="Mechamorphosis.php">Mechamorphosis</a>
        
        <a class="n" href="Paripath.php">Paripath</a>
        <a class="n" href="Philosophiae.php">Philosophiae</a>
        <a class="n" href="Vihang.php">Vihang</a>
          <a class="n" onclick="document.getElementById('contact').style.display='block'" >LogIn</a>            <div id="contact" class="w3-modal"> 
                <div class="w3-modal-content w3-animate-zoom">
                    <div class="w3-container w3-black w3-leftbar">
                       <span onclick="document.getElementById('contact').style.display='none'" class="w3-button w3-display-topright w3-large"><p id="close">x</p></span>
                        <h1 id="Log">LogIn</h1>
                    </div>
                    <div class="w3-container w3-black w3-leftbar">
                    <br>
                    <div>
                            <!-- <h2>Login Information</h2> -->
                           
                           <br>
                            <div>
                                <label for="username" id="user">Username</label>
                                <br><br>
                                <input type="text"  class="w3-input w3-padding-5 w3-border-bottom w3-black" name="username" id="username">
                            </div>
                            <br>    
                            <div>
                                <label for="password" id="user">Password</label>
                                <br>
                                <br>
                                <input type="password" class="w3-input w3-padding-5 w3-border-bottom w3-black" name="password" id="password">
                            </div>    
                            <p id="signerr"></p>
                            <button onclick="login()" class="w3-button w3-hover-none w3-tiny w3-black" ><p id="user1">Login</p></button>
                            
                        </div>
                       <p> <a href="../pass.php" target="_blank">Forgot your password?</a> </p> 
                         <p> <a target="_blank" href="../signup.html">Sign Up</a> </p>            
                     </div>
                   </div>
                  </div> <a class="n" href="javascript:void(0);" style="font-size:20px;color:silver" id="icon" onclick="myFunction()">&#9776;</a>
                    </div>


 <div class="w3-display-container w3-animate-opacity">


  <img src="img/kaleidoscope.jpg" alt="boat" style="width:100%;min-height:350px;max-height:400px;"><h1 class="  w3-animate-bottom centered titleeve1">KALEIDOSCOPE</h1>
  <div class="w3-container w3-display-bottomleft w3-margin-bottom">  
  </div>
</div>	
<div class="w3-row-padding w3-center w3-margin-top">
  <!--   event1 sarts here copy and paste this code and change the content accordingly -->
    <div class="w3-third">
        <div class="w3-card w3-container ckhaki w3-margin-top" style="min-height:460px">
        <h3 class="Ab1">Ricerca</h3><br>	
        <img src="../images/logo/paper presentation logo.png" height="35%" width="35%"></img>
        
         <p class="Ab"><button onclick="document.getElementById('AboutRicerca').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
        </p>
        <div id="AboutRicerca" class="w3-modal">
          <div class="w3-modal-content w3-animate-zoom">
            <div class="w3-container w3-black w3-display-container">
              <span onclick="document.getElementById('AboutRicerca').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
              <h1 style="font-family:'icon1'; font-size:38px;">Ricerca</h1>
            </div>
            <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
                <br>
               <p class="Ab">
           "The progressive development of man is vitally dependent on invention. It is the most important product of his creative brain." -  Nikola Tesla.
          <br><br>A platform for the budding researchers, Ricerca promises to test your creativity, coupled with your scientific knowledge and your perseverance. Join in if you feel that you can come up with something original and that you can defend your line of thought with logical explanations. 
          </p>
          <br><br><h3  class="Ab2">Departments</h3>
          <ol class="list">
          <li>Astronomy and Astrophysics</li>
          <li>Mechanical</li>
          <li>Electrical/Electronics</li>
          <li>Computer Science and Information Technology</li>
          <li>Physics</li>
          </ol> 
          <br><br><h3  class="Ab2">Format</h3>
          <ol class="list">
          <li>The event consists of 2 rounds.</li>
          <li>The selection in the first round will be based on the paper submitted.</li>
          <li>Every team needs to send their entries to events@conscientia.co.in in Microsoft Word(.doc/.docx) or printable document(.pdf), in IEEE  or other internationally recognized formats.</li>
          <li>The second round shall consist of a presentation before a bench of judge(s).</li>
          <li>The participants will be given 10 minutes to present their paper before a panel of judges and around extra 5 minutes for questions and answers as per discretion of judges.</li>
          <li>The team should mention the department under which it chooses to present.</li>
          </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 24,000</p>
          </div>
          </div>
      </div>
      <p class="Ab"><button onclick="document.getElementById('RulesRicerca').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
        </p><div id="RulesRicerca" class="w3-modal">
          <div class="w3-modal-content w3-animate-zoom">
            <div class="w3-container w3-black w3-display-container">
              <span onclick="document.getElementById('RulesRicerca').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
              <h1 style="font-family:'icon1'; font-size:38px;">Ricerca</h1>
            </div>
            <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
                <br><br><h3  class="Ab2">Rules</h3>
               <ol class="list">
          <li>Only Under-graduates students are eligible for this competition.</li>
          <li>A maximum of 2 participants in a team can register.</li>
          <li>A team can register for this event in more than one department specified above. </li>
          <li>Papers with incorrect format shall be sent back for correction, and can be resubmitted only once, after being returned, failing which they shall be deemed as disqualified.</li>
          <li>Exceeding of time limit in the second round will invoke negative points.</li>
          <li>For every extra minute taken a certain number of points will be deducted from the total. </li>
          <li>The participants can include any type of media (pictures, videos, audio) in their presentation, provided they do not show any controversial clips.</li>
          <li>Re-presentation of papers already presented in other competitions / conferences are strictly prohibited. If the team is found to be involved in plagiarism, he/she will be disqualified immediately.</li>
          <li>If the candidate fails to meet any one of the above mentioned, he/she will be subjected to disqualification.</li>
          <li>Decision of judges will be final and binding on all participants. Any discussions regarding evaluation process at any stage shall not be entertained.</li>
          </ol> 
          </div>
          </div>
      </div>
      <p class="Ab"><button onclick="document.getElementById('ContactRicerca').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
        </p><div id="ContactRicerca" class="w3-modal">
          <div class="w3-modal-content w3-animate-zoom">
            <div class="w3-container w3-black w3-display-container">
              <span onclick="document.getElementById('ContactRicerca').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
              <h1 style="font-family:'icon1'; font-size:38px;">Ricerca</h1>
            </div>
            <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
                <br><br><h3  class="Ab2">Contacts</h3>
               <ol class="list">
          <li>Amisha : 9447784629</li>
          <li>Samridhi : 9915314098 </li>
          </ol>
          </div>
          </div>
      </div>
        <button onclick="event_reg('ricerca')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
        </div>
      </div>

      <!--   event one ends here -->
 <!--   event1 sarts here copy and paste this code and change the content accordingly -->
 <div class="w3-third">
  <div class="w3-card w3-container ckhaki w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Black Box</h3><br>	
  <img src="../images/logo/Black box logo.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutBlackBox').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutBlackBox" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutBlackBox').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Black Box</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
     "Originality is the essence of true scholarship. Creativity is the soul of the true scholar."  -  Nnamdi Azikiwe
    <br><br>If you think you have creative insight in the way machines work, then this is the event for you. Come prepared as you will be tested with some challenging Mechanisms.
    </p> 
    <br><br><h3  class="Ab2">Format</h3>
    <ol class="list">
    <li>You will have to build some mechanisms/machine with some material given to you in a specified amount of time.</li>
    <li>Then your machine/mechanism will be tested performance and robustness wise, points will be given according to that.</li>
    <li>There can be any number of teams with each team having a maximum of 3 participants.</li>
    <li>This will be a 2-day Event, the events on both days are independent of each other.</li>
    </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 6,000</p>
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesBlackBox').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesBlackBox" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesBlackBox').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Black Box</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>No outside Materials are allowed, all the materials required to make the mechanisms will be provided by the organizers.</li>
    <li>Mobile phones will not be allowed.</li>
	<li>Other rules will be decided on the spot.</li>
    </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactBlackBox').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactBlackBox" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactBlackBox').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Black Box</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Abhishek : 9497300041</li>
    <li>Souradeep: 9830533587</li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('black_box')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
</div>

<!--   event one ends here -->
 <!--   event1 sarts here copy and paste this code and change the content accordingly -->
 <div class="w3-third">
  <div class="w3-card w3-container ckhaki w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Techwiz</h3><br>	
  <img src="../images/logo/techwiz logo.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutTechwiz').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutTechwiz" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutTechwiz').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Techwiz</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
     QUIZZERS-ALERT!!!! 
Are you passionate about corporate ordeals and fancy gadgets? If business and technology is a piece of cake for you, then we invite you to make your way through the crowd, where all your knowledge about Technology will decide the ratio of Smartness and Geekiness in you! If you are confident with your tech trivia, this is your chance to be the Techwhiz.

    </p>
    
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 6,500</p>
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesTechwiz').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesTechwiz" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesTechwiz').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Techwiz</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li> Teams comprising of 2 members are invited.</li>
    <li>The event will be held in two rounds </li>
    <li>The preliminary level will be a written round. </li>
    <li>The qualified teams will battle it out on the stage.</li>
    <li>The stage quiz will contain several rounds comprising of straight-answer type questions, audio-visuals, and rapid-fire questions, spanning all aspects of Technology and Business.</li>
    <li>Winners will be decided based on the score at the end of the final round. The scores will be awarded as per rules set down by the organizers. </li>
    <li>The decision of the organizers is final and binding under all circumstances.</li>
    </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactTechwiz').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactTechwiz" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactTechwiz').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Techwiz</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Jacob : 9496481043</li>
    <li>Abel : 8547943835 </li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('Techwiz')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
</div>

<!--   event one ends here -->
 <!--   event1 sarts here copy and paste this code and change the content accordingly -->
 <div class="w3-half">
  <div class="w3-card w3-container ckhaki w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Alpha Geek</h3><br>	
  <img src="../images/logo/Alpha geek logo.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutAlphaGeek').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutAlphaGeek" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutAlphaGeek').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Alpha Geek</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
     Being a Dude is too mainstream, if you are a geek then standout, prove it to everyone that you are a geek, not the gamma, or beta but the alpha.
    </p>
    <br><br><h3  class="Ab2">Format</h3>
    <ol class="list">
    <li>Level 1 will be Question Paper based having 20-25 questions.</li>
    <li>Level 2 will be Constructive Question Paper with 10-15 questions having connections within themselves and real world. Top 3 will be selected. If there is a tie, a tie-breaker event would be conducted.</li>
    <li>Level 3 will development of solution based event in which you have to develop a solution to a given problem with given materials. Only 1 winner.</li>
    </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 6,000</p>
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesAlphaGeek').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesAlphaGeek" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesAlphaGeek').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Alpha Geek</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>No use of calculator or any other electronics device.</li>
    <li>Participants can leave the room at any time after handling the answer sheets to the organizer. This rule applies for level 1 and level 2.</li>
    <li>In case of any malpractice, team will be disqualified by the organizers. </li>
    <li>In case of tie-break, Tie-breaker would be decided by the organizer during the event.</li>
    <li>The decision of event organizer will be final and binding.</li>
    <li>Rules for the 3rd level would be announced during the event itself. </li>
    <li>Further rules about the event will be discussed at the venue itself.</li>
    </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactAlphaGeek').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactAlphaGeek" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactAlphaGeek').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Alpha Geek</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Ankit : 9447786217</li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('alpha_geek')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
</div>

<!--   event one ends here -->
 <!--   event1 sarts here copy and paste this code and change the content accordingly -->
 <div class="w3-half">
  <div class="w3-card w3-container ckhaki w3-margin-top" style="min-height:460px">
  <h3 class="Ab1">Bletchley Park</h3><br>	
  <img src="../images/logo/war of bots icon.png" height="35%" width="35%"></img>
  
   <p class="Ab"><button onclick="document.getElementById('AboutBletchlyPark').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">About</button>
  </p>
  <div id="AboutBletchlyPark" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('AboutBletchlyPark').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Bletchly Park</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br>
         <p class="Ab">
     Cryptography is the ultimate form of non-violent direct action. -  Julian Assange
    <br><br>Secret call for help: Help us decode our messages and in return, get a chance to be at Bletchley Park. If you feel that you can extract the information amidst a sea of chaos, this event is here for you. Register to play the game for the game itself.
    </p>
    <br><br><h3  class="Ab2">Format</h3>
    <ol class="list">
    <li>The competition consists of 2 rounds.</li>
    <li>Round 1 will be a written round.</li>
    <li>Round 2 will be a surprise whose rules will be disclosed on spot.</li>
    <li>A team can comprise of a maximum of 2.</li>
    </ol> 
               <h3 class="Ab2">Prize Money </h3><p class="Ab3">₹ 7,000</p>
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('RulesBletchlyPark').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Rules</button>
  </p><div id="RulesBletchlyPark" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('RulesBletchlyPark').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Bletchly Park</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Rules</h3>
         <ol class="list">
    <li>Use of electronic equipment like cell phones, etc. is strictly prohibited and shall be punished by disqualification.</li>
    <li>Please be on time, otherwise you will not be rewarded with extra time and you have to put in more effort than the other participants.</li>
    </ol> 
    </div>
    </div>
</div>
<p class="Ab"><button onclick="document.getElementById('ContactBletchlyPark').style.display='block'" class="w3-button  w3-theme w3-hover-teal" style="font-size:20px">Contact</button>
  </p><div id="ContactBletchlyPark" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom">
      <div class="w3-container w3-black w3-display-container">
        <span onclick="document.getElementById('ContactBletchlyPark').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
        <h1 style="font-family:'icon1'; font-size:38px;">Bletchly Park</h1>
      </div>
      <div class="w3-container w3-white w3-leftbar w3-rightbar w3-bottombar w3-border-azure w3-padding-large ">
          <br><br><h3  class="Ab2">Contacts</h3>
         <ol class="list">
    <li>Abhishek : 9497300041</li>
    <li>Souradeep: 9830533587</li>
    </ol>
    </div>
    </div>
</div>
  <button onclick="event_reg('bletchly_park')" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS" class="Ab">Register</button>
  </div>
</div>

<!--   event one ends here -->

</div>
</body>